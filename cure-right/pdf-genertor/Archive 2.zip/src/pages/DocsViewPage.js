import React, {useState } from "react";
import Report3 from "../components/ExportPdf/Report3";


function DocsViewPage() {
 
  return (
    <div>
      <div className="mt-3">
              <Report3
              />
      </div>
    </div>
  );
}

export default DocsViewPage;