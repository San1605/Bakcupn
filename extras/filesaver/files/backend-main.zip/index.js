const dotenv = require('dotenv');
const express = require('express');
const cors = require("cors");
const path = require('path');
const compression = require('compression');
const {dbConnection,connection} = require("./src/utils/dbConnection");


const bodyParser = require('body-parser');
const multer = require('multer');
const upload = multer();
let userRouter = require("./src/routes/private.route");
let storeRouter = require("./src/routes/storeRoute.routes");
let banners = require("./src/routes/banner.routes");
let stores = require("./src/routes/stores.route");
let coupon = require("./src/routes/coupon.routes");
let cities = require("./src/routes/cities.routes");
let booking = require("./src/routes/booking.route");
let notification = require("./src/routes/notification.routes");
let cart = require("./src/routes/cart.route");
let rating = require("./src/routes/ratings.route");
let transaction = require("./src/routes/transactions.route");
/*********************************************************** */
let admin = require("./src/routes/admin.routes");
/*********************************************************** */


const authJwt = require("./src/middleware/authJwt");
const app = express();
dotenv.config({ path: './config.env' });

app.get('/', (req, res) => {
    res.send('HiWay Food Apis');
});

var corsOptions = {
    origin: "http://localhost"
};
app.use((req, res, next) => {
    console.log(req.method, " ", req.path)
    next()
})
app.use(compression({
    level: 1,
    threshold: 10 * 1000,
    filter: (req, res) => {
        if (req.headers['x-no-compression']) {
            return false
        }
        return compression.filter(req, res)
    },
}));


app.use(cors(corsOptions));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(upload.array());

const PORT = process.env.PORT || 5621;
/* routes */
require('./src/routes/auth.routes')(app);

dbConnection()
  .then((status) => {
    console.log(status);
    app.listen(process.env.PORT || 3000, () => {
      console.log(
        `App listening at http://localhost:${process.env.PORT || 3000}`
      );
    });
  })
  .catch((err) => console.log(err));
// app.listen(PORT, function (err) {
//     if (err) console.log("Error in server setup")
//     console.log(`Server listening on Port ${PORT}`);
// })


app.use('/user/api', [authJwt.verifyToken], userRouter)
app.use('/routes/api', [authJwt.verifyToken], storeRouter)
app.use('/banners/api', [authJwt.verifyToken], banners)
app.use('/stores/api', [authJwt.verifyToken], stores)
app.use('/coupon/api', [authJwt.verifyToken], coupon)
app.use('/cities/api', [authJwt.verifyToken], cities)
app.use('/booking/api', [authJwt.verifyToken], booking)
app.use('/notification/api', [authJwt.verifyToken], notification)
app.use('/cart/api', [authJwt.verifyToken], cart)
app.use('/rating/api', [authJwt.verifyToken], rating)
app.use('/transaction/api', [authJwt.verifyToken], transaction)
/******************************************************************* */
app.use('/admin/api', admin)
/******************************************************************** */
