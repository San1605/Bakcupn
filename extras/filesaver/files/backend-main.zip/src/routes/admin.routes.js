const express = require("express");
const router =  express.Router();
const adminController = require("../controller/admin.controller");


router.get("/dashboardCounts",adminController.dashboardCounts);
router.get("/orders",adminController.orders);
router.get("/viewOrders",adminController.viewOrders);
router.post("/addCategories",adminController.addCategories);
router.get("/storeCategories",adminController.storeCategories);
module.exports = router;

