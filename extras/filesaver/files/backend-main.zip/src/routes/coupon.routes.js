const express = require("express");
const router =  express.Router();
const couponController = require("../controller/coupon.controller");

router.get("/list/:id",  couponController.list);
router.post("/verify_coupon",  couponController.verfiyCoupon);

module.exports = router;

