const express = require("express");
const router =  express.Router();
const cartController = require("../controller/cart.controller");

router.post("/add",  cartController.addToCart);
router.get("/my_cart",  cartController.myCart);
router.post("/remove_cart_product",  cartController.removeCartProduct);
router.get("/cear_cart",  cartController.clearCart);

module.exports = router;