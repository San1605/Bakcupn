const express = require("express");
const router =  express.Router();
const bookingController = require("../controller/booking.controller");
const userController = require("../controller/auth.controller");


router.get("/my_notifications",  bookingController.myNotification);
router.post("/web_push_notification",  userController.webPushNotification);

module.exports = router;


