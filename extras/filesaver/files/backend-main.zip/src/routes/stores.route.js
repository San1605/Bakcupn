const express = require("express");
const router = express.Router();
const storeController = require("../controller/stores.controller");

router.get("/details/:id", storeController.storeDeatils);
router.get("/productlist/:id", storeController.storeProduct);
router.post("/near_stand/", storeController.nearBusStand);
router.get("/facilitie_list/", storeController.facilitiesList);
router.post("/", storeController.addStore)
module.exports = router;

