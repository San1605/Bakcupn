const express = require("express");
const router =  express.Router();
const storeRouteController = require("../controller/storeRoutes.controller");

router.get("/storeroutes",  storeRouteController.routeList);
module.exports = router;

