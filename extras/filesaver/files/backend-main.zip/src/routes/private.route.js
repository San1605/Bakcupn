const express = require("express");
const router =  express.Router();
const userController = require("../controller/auth.controller");
const storeRouteController = require("../controller/storeRoutes.controller");

router.get("/getprofile",  userController.getProfile);
router.post("/updateprofile",  userController.updateProfile);
router.post("/feedback",  userController.userFeedback);
router.post("/update_device_token",  userController.updateDeviceToken);
router.post("/enquiry",  userController.enquiry);

module.exports = router;

