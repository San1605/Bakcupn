const express = require("express");
const router =  express.Router();
const tranasactionController = require("../controller/transaction.controller");

router.post("/checksum",  tranasactionController.generateChecksum);
router.post("/verify_checksum",  tranasactionController.verifyChecksum);
router.post("/pay_bill",  tranasactionController.payBill);
module.exports = router;

