const express = require("express");
const router =  express.Router();
const bookingController = require("../controller/booking.controller");


/* table bookin route */
router.post("/table_booking",  bookingController.tableBooking);
router.get("/booking_list/:order_status",  bookingController.bookingList);
router.get("/booking_details/:booking_id",  bookingController.bookingDetails);
router.get("/cancel_booking/:booking_id",  bookingController.bookingCancel);
router.get("/booking_status",  bookingController.bookingStatus);

/* order bookin routes */
router.post("/order_booking",  bookingController.orderBooking);
router.get("/order_booking_cancel/:booking_id",  bookingController.orderBookingCancel);

router.post("/update_arival_time",  bookingController.updateArivalTime);

module.exports = router;


