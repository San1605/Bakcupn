const express = require("express");
const router =  express.Router();
const bannerController = require("../controller/banner.controller");

router.get("/bannerlist",  bannerController.bannerList);
module.exports = router;

