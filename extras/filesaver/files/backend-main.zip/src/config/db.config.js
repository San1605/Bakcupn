const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });

module.exports = {
    HOST: process.env.DB_HOST,
    USER: process.env.DB_USER,
    logging: false,
    PASSWORD: process.env.DB_PASS,
    DB: process.env.DB,
    dialect: "mysql",
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }

};