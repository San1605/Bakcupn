const db = require("../models");
const Banners = db.banners;

exports.bannerList = async (req, res) => {
    await Banners.findAll({
        where: {
            is_section : req.query.type,
            route_id : req.query.route_id,
            status : 1,
        },
    })
        .then(banners => {
            if (banners.length === 0) {
                return res.status(200).json({ status: false, message: "No banner found", data: [] });
            } else {
                return res.status(200).json({ status: true, message: "banner get successfully", data: banners });
            }

        })
        .catch(err => {
            return res.status(200).json({ status: false, message: `something went worng ${err}`, data: [] });
        });
};
