var PaytmChecksum = require("paytmchecksum");
const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });
const https = require('https');
const db = require("../models");
const { response } = require("express");
const Transaction = db.transaction;
const PayBills = db.pay_bills;
const User = db.user;


exports.generateChecksum = async (req, res) => {
    // var paytmParams = {};

    // paytmParams["MID"] = process.env.PAYTM_MID;
    // paytmParams["ORDERID"] = req.body.order_id;

    // var paytmChecksum = PaytmChecksum.generateSignature(paytmParams, process.env.PAYTM_M_KEY);
    // paytmChecksum.then(function (checksum) {
    //     return res.status(200).json({ status: true, message: "Checksum signature key", data: { signature: checksum, merchant_id: process.env.PAYTM_MID } });
    // }).catch(function (error) {
    //     return res.status(400).json({ status: false, message: error.message, data: {} });
    // });
    var paytmParams = {};
    paytmParams.body = {
        "requestType": "Payment",
        "mid": process.env.PAYTM_MID,
        "websiteName": "WEBSTAGING",
        "orderId": req.body.order_id,
        "callbackUrl": `https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=${req.body.order_id}`,
        "txnAmount": {
            "value": req.body.amount,
            "currency": req.body.currency,
        },
        "userInfo": {
            "custId": req.user,
        },
    };

    PaytmChecksum.generateSignature(JSON.stringify(paytmParams.body), process.env.PAYTM_M_KEY)
        .then(async (checksum) => {
            paytmParams.head = {
                "signature": checksum
            };
            var post_data = JSON.stringify(paytmParams);
            var options = {
                //for Staging 
                hostname: 'securegw-stage.paytm.in',
                /* for Production */
                //hostname: 'securegw.paytm.in',
                port: 443,
                path: `/theia/api/v1/initiateTransaction?mid=${process.env.PAYTM_MID}&orderId=${req.body.order_id}`,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': post_data.length
                }
            };

            var response = "";
            var post_req = await https.request(options, async (post_res) => {
                await post_res.on('data', (chunk) => {
                    response += chunk;
                });

                post_res.on('end', function () {
                    console.log("response", response)
                    let token_response = JSON.parse(response)
                    return res.status(200).json({ status: true, message: "Checksum signature key", data: { signature: checksum, txnToken: token_response.body.txnToken, merchant_id: process.env.PAYTM_MID, response: JSON.parse(response) } });
                });
            });
            post_req.write(post_data);
            post_req.end();
            //return res.status(200).json({ status: true, message: "Checksum signature key", data: { signature: checksum, merchant_id: process.env.PAYTM_MID, response: "" } });
        }).catch((err) => {
            console.log("err", err)
        })
};

exports.verifyChecksum = async (req, res) => {
    try {
        let paytmChecksum = req.body.checksum;
        delete req.body.checksum;
        var isVerifySignature = PaytmChecksum.verifySignature(req.body, process.env.PAYTM_M_KEY, paytmChecksum);
        if (isVerifySignature) {
            return res.status(200).json({ status: true, message: "Checksum matched", data: {} });
        } else {
            return res.status(400).json({ status: false, message: "Checksum mis matched", data: {} });
        }
    } catch (error) {
        return res.status(400).json({ status: false, message: error.message, data: {} });
    }
};

exports.payBill = async (req, res) => {
    try {
        let user = await User.findOne({ where: { phone: req.user } });
        let genRanHex = '#' + Math.floor(Math.random() * 1000000000);
        await PayBills.create({
            user_id: user.id,
            store_id: req.body.store_id,
            route_id: req.body.route_id,
            discount_amount: req.body.discount_amount,
            final_amount: req.body.final_amount,
            service_charge: req.body.service_charge,
            taxes: req.body.taxes,
            transaction_id: req.body.transaction_id,
            hash_id : genRanHex,
            transaction_date: new Date().toISOString().slice(0, 10),
            coupon_id: req.body.coupon_id,
        }).then(async (response) => {
            await Transaction.create({
                relation_id: response.id,
                transaction_id: req.body.transaction_id,
                amount: req.body.final_amount,
                booking_type: "pay bill",
                payment_mode: "online",
                store_id: req.body.store_id,
                user_id: user.id,
                transaction_date: new Date().toISOString().slice(0, 10),
                payment_type: "credit"
            });
            return res.status(200).json({ status: true, message: "Bill successfully paid", data: response });
        })
    } catch (error) {
        return res.status(400).json({ status: false, message: error.message, data: {} });
    }
}
