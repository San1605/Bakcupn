const db = require("../models");
const {
    sendOtp,
} = require("../utils/sendOtp");
const {
    generateToken,
    updateToken,
} = require("../utils/generateToken");

const {
    sendWebushNotification
} = require("../utils/sendNotifications");


const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });

const User = db.user;
const Feedback = db.feedbacks;
const otpVerification = db.otp;
const Enquiry = db.enquirers;
const Op = db.Sequelize.Op;
const Stores = db.stores;
var tokenList = {}

exports.signup = (req, res) => {
    User.findOne({
        where: {
            phone: req.body.phone
        }
    }).then(async (user) => {
        if (user) {
            if (user.status == 1) {
                if (user.imei_number == req.body.imei_number) {
                    /* user register and send update token */
                    await sendOtp(req.body.phone);
                    let response = await generateToken(req.body.phone);
                    res.status(200).json({ status: true, message: "otp send successfully", data: response });
                } else {
                    /* register a new device */
                    await sendOtp(req.body.phone);
                    res.status(200).json({ status: true, message: "otp send successfully", data: {} });
                }
            } else {
                res.status(401).json({ status: false, message: "Your account is suspend ! Please contact to admin", data: {} });
            }
        }

        if (!user) {
            /* register a new device */
            const userdata = {
                phone: req.body.phone,
                role_id: 4,
            };
            await User.create(userdata);
            await sendOtp(req.body.phone);
            res.status(200).json({ status: true, message: "otp send successfully", data: {} });
        }
    }).catch((error) => {
        res.status(500).send({ message: error.message });
    })
};

exports.verifyotp = (req, res) => {
    console.log("req.body.mobile", req.body.mobile, req.body.otp)
    otpVerification.findOne({
        where: { phone: req.body.mobile, otp: req.body.otp }
    }).then(async data => {
        if (data) {
            const UserCollection = await User.findOne({
                where: {
                    phone: req.body.mobile
                }
            });

            if (UserCollection) {
                var userdata = await UserCollection.update({
                    imei_number: req.body.imei_number,
                    device_name: req.body.device_name,
                    deviceToken: req.body.deviceToken,
                    deviceType: req.body.deviceType,
                });
            }
            else {
                res.status(401).json({ status: false, message: "something went worng", data: {} });
            }

            const userdetails = await User.findOne({
                where: {
                    phone: req.body.mobile
                },
                raw: true,
            });

            let response = await generateToken(req.body.mobile);
            let data = { ...userdetails, ...response };
            res.status(200).json({ status: true, message: "otp successfully matched", data: data });
        } else {
            res.status(200).json({ status: false, message: "Invalid otp", data: {} });
        }
    })
        .catch(err => {
            res.status(500).send({
                message: "Some thing went worng"
            });
        });
}

exports.token = async (req, res) => {
    // refresh the damn token
    const postData = req.body
    // if refresh token exists
    try {
        if ((postData.refreshToken)) {
            let token = await updateToken(req.body.mobile);
            const response = {
                "token": token,
            }
            res.status(200).send({ status: true, message: "refresh token", data: response });
        } else {
            res.status(404).send({ status: false, message: error.message });
        }
    } catch (error) {
        res.status(404).send({ status: false, message: error.message });
    }
}

exports.getProfile = (req, res) => {
    User.findOne({
        where: {
            phone: req.user
        }
    })
        .then(user => {
            return res.status(200).send({ status: true, message: "User profile", data: user });
        })
        .catch(err => {
            return res.status(200).send({ status: false, message: "User profile", data: {} });
        });
}

exports.updateProfile = (req, res) => {
    let user_data = {
        name: req.body.name, email: req.body.email, traveller_type: req.body.traveller_type, travel_mode: req.body.travel_mode
    }
    User.update(user_data, {
        where: { phone: req.user }
    })
        .then(num => {
            return res.status(200).send({ status: true, message: "User profile successfully update", data: {} });
        })
        .catch(err => {
            return res.status(200).send({ status: false, message: "Something went worng please try again", data: {} });
        });
}

exports.userFeedback = (req, res) => {
    User.findOne({
        where: {
            phone: req.user
        }
    })
        .then(async user => {
            let feedbacks_data = {
                title: req.body.title,
                user_id: user.id
            }
            await Feedback.create(feedbacks_data);
            return res.status(200).send({ status: true, message: "Feedback successfully submit", data: {} });
        })
        .catch(err => {
            return res.status(200).send({ status: false, message: "User profile", data: {} });
        });
}

exports.updateDeviceToken = async (req, res) => {
    try {
        await User.update(
            { deviceToken: req.body.device_token },
            { where: { phone: req.user } });
        return res.status(200).send({ status: true, message: "Device Token Updated", data: {} });
    } catch (error) {
        return res.status(400).send({ status: false, message: error.message, data: {} });
    }
}

exports.enquiry = async (req, res) => {
    try {
        await Enquiry.create(req.body);
        return res.status(200).send({ status: true, message: "Enquiry Added", data: {} });
    } catch (error) {
        return res.status(400).send({ status: false, message: error.message, data: {} });
    }
}

exports.webPushNotification = async (req, res) => {
    let store_data = await Stores.findOne({
        where: { id: req.body.store_id },
    });

    let user_id = store_data.user_id;
    await sendWebushNotification(user_id, req.body.message);
    return res.status(200).json({ status: true, message: `Notification send successfully`, data: {} });
}

