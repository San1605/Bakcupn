const { stores } = require("../models");
const db = require("../models");
const Stores = db.stores;
const Users = db.user;
const Ratings = db.ratings;
const StoreDiscount = db.store_discounts;
const StoreImages = db.store_images;
const Storeproducts = db.store_products;
const StoreproductsCategor = db.product_categories;
const Products = db.products;
const HotelFacilities = db.hotel_facilities;
const Op = db.Sequelize.Op;
const BookingProducts = db.booking_products;
const OrderBooking = db.order_bookings;
const TableBooking = db.table_bookings;
const Coupons = db.coupon;
exports.addStore = async (req, res) => {
    try {
        // if (!req.params.id) {
        //     res.status(200).json({ status: false, message: "something went worng", data: {} });
        // } else {
            var data = []
        let stores = await Stores.findAll({
            where: {
              route_id: req.body.route_id
            }
          })
        
        if(stores.length>0){
          for(let i=0;i<stores.length;i++)
                try{
                    let rating = await Ratings.findAll({
                        where: {
                          store_id: stores[i].id,
                          user_id:stores[i].user_id
                        }
                      })
                      let orderBooking = await OrderBooking.findAll({
                        where: {
                          store_id: stores[i].id,
                          user_id:stores[i].user_id
                        }
                      })
                    
                      let tableBooking = await TableBooking.findAll({
                        where: {
                          store_id: stores[i].id,
                          user_id:stores[i].user_id
                        }
                      })
                      let storeDiscount = await StoreDiscount.findAll({
                        where: {
                          store_id: stores[i].id
                        }
                      })
                  
                      let coupons = await Coupons.findAll({
                        where: {
                            route_id: req.body.route_id,
                           // name:orderBooking[0].coupon
                        }
                      })
                      let storedata =  {
                        "id": stores[i].id? stores[i].id:"",
                        "name": stores[i].name? stores[i].name:"",
                        "image": stores[i].image? stores[i].image:"",
                        "store_ratting": rating.length>0?rating[0].rating_value:"",
                        "images": "",//
                        "open_time": stores[i].open_time? stores[i].open_time:"",
                        "food_type": orderBooking.length>0?orderBooking[0].food_type:"",
                        "close_time": stores[i].close_time? stores[i].close_time:"",
                        "distance": "0.0",
                        "latitude": stores[i].latitude?stores[i].latitude:"",
                        "longitude": stores[i].longitude?stores[i].longitude:"",
                        "discount_percentage": storeDiscount.length>0?storeDiscount[0].discount_percentage:"",
                        "discount_type": storeDiscount.length>0?storeDiscount[0].discount_type?storeDiscount[0].discount_type:"":"",
                        "discount_value": orderBooking.length>0?orderBooking[0].discount_amount:"",
                        "is_restaurant_type": stores[i].is_restaurant_type?stores[i].is_restaurant_type:"",
                        "discount_amount": orderBooking.length>0? orderBooking[0].discount_amount:"",
                        "order_type": tableBooking.length>0?tableBooking[0].order_type:"",
                        "type": "",// 
                        "minimum_amount": coupons.length>0?coupons[0].minimum_amount:"",
                        "valid_to": coupons.length>0?coupons[0].valid_to:"",
                        "valid_date": coupons.length>0?coupons[0].valid_date:"",
                        "description":coupons.length>0?coupons[0].description:"",
                        "maxmum_amount": coupons.length>0?coupons[0].maxmum_amount:"",
                        "selectedData": "",//coupons[0].,
                        "hash_id": stores[i].hash_id,
                        "bookig_date": tableBooking.length>0?tableBooking[0].bookig_date:"",
                        "bookig_time": tableBooking.length>0?tableBooking[0].bookig_time:"",
                        "booking_type": tableBooking.length>0?tableBooking[0].booking_type:"",
                        "payable_amount":  orderBooking.length>0?orderBooking[0].payable_amount:"",
                        "no_gest": tableBooking.length>0?tableBooking[0].no_gest:"",
                        "group_type": tableBooking.length>0?tableBooking[0].group_type:"",
                        "username": tableBooking.length>0?tableBooking[0].username:"",
                        "phone": tableBooking.length>0?tableBooking[0].phone:"",
                        "created_at": stores[i].created_at,
                        "title:": "",//
                        "message": "",//
                        "status": "",//
                        "amount:": "",//
                        "store": {
                          "name": stores[i].name,
                          "id": stores[i].id,
                          "is_restaurant_type": stores[i].is_restaurant_type?stores[i].is_restaurant_type:"",
                          "image": stores[i].is_restaurant_type,
                          "latitude": stores[i].latitude,
                          "longitude": stores[i].longitude,
                          "mobile": stores[i].mobile,
                          
                        }}
                    data.push(storedata)
                    //   let bookingProducts = await BookingProducts.findAll({
                    //     where: {
                    //       store_id: stores[i].id,
                    //       user_id:stores[i].user_id
                    //     }
                    //   })
                }catch(err) { res.status(500).json({ status: false, message: "Data err successfully", data: err.message });}
               
              
            
          
        }
        res.status(200).json({ status: true, message: "Data added successfully", data: data });
        
        // }


    } catch (error) {
        res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: {} });
    }


};

exports.storeDeatils = async (req, res) => {
    try {
        if (!req.params.id) {
            res.status(200).json({ status: false, message: "something went worng", data: {} });
        }

        let StoresData = await Stores.findOne({
            where: {
                id: req.params.id,
                admin_status: true,
                status: true
            }
        });

        let StoreDiscountData = await StoreDiscount.findOne({
            where: {
                store_id: req.params.id,
                status: true
            },
        });


        let StoreImagesData = await StoreImages.findAll({
            where: {
                store_id: req.params.id,
                status: true
            },
        });

        let RatingsData = await Ratings.findOne({
            where: {
                store_id: req.params.id,
                user_id: 1,
            },
            attributes: ['rating_value']
        });

        let storeComment = await Ratings.findAll({
            include: {
                model: Users,
                attributes: ['name']
            },
            where: {
                store_id: req.params.id,
                user_id: {
                    [Op.not]: 1
                },
                store_comment: {
                    [Op.ne]: null
                }
            },
            attributes: ['store_comment', 'created_at']
        });

        // //JSON.parse(JSON.stringify(StoresData.facilities))
        let facilitiesData = await HotelFacilities.findAll({
            where: {
                id: JSON.parse(StoresData.facilities)
            },
            attributes: ['id', 'name']
        });

        let data = {
            "StoresData": StoresData,
            "RatingsData": RatingsData?.rating_value ?? 0,
            'StoreDiscountData': StoreDiscountData,
            'StoreImagesData': StoreImagesData,
            'facilities_data': facilitiesData,
            'store_comments': storeComment,
            'link': "http://3.109.44.142/storage/upload/store_images/",
        }

        res.status(200).json({ status: true, message: "Data get successfully", data: data });

    } catch (error) {
        res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: {} });
    }


};

exports.storeProduct = async (req, res) => {
    try {
        if (!req.params.id) {
            res.status(200).json({ status: false, message: "something went worng", data: {} });
        }

        var StoreProductsCateoryData = await Storeproducts.findAll({
            include: {
                model: StoreproductsCategor,
                attributes: ['id', 'name']
            },
            where: {
                store_id: req.params.id,
                status: true
            },
            group: ['food_category_id'],
        });

        var result = [];
        for (let i = 0; i < StoreProductsCateoryData.length; i++) {
            let data = await Storeproducts.findAll({
                include: [{
                    model: StoreproductsCategor,
                    attributes: ['id', 'name']
                }, {
                    model: Products,
                    attributes: ['id', 'name', 'amount']
                }],
                where: {
                    food_category_id: StoreProductsCateoryData[i].food_category_id,
                    store_id: req.params.id,
                    status: true
                },
            });
            var obj = {};
            obj['product_category'] = data;
            result.push(obj);
        }
        res.status(200).json({ status: true, message: "Data get successfully", data: result });
    } catch (error) {
        res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: {} });
    }
}

exports.nearBusStand = async (req, res) => {
    try {
        const StoreData = await Stores.findAll({
            where: {
                name: {
                    [Op.like]: `%${req.body.name}%`
                },
                route_id: req.body.route_id,
                is_bus_stand: 1,
                city_id: req.body.city_id,
                status: 1
            }
        });
        res.status(200).json({ status: true, message: "Data get successfully", data: StoreData });
    } catch (error) {
        res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: {} });
    }
}

exports.facilitiesList = async (req, res) => {
    try {
        const data = await HotelFacilities.findAll();
        res.status(200).json({ status: true, message: "Data get successfully", data: data });
    } catch (error) {
        res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: {} });
    }
}
//  {
//     "status": false,
//     "message": "message",
//     "data": [
//       {
//         "id": "",
//         "name": "",
//         "image": "",
//         "store_ratting": "0",
//         "images": "",
//         "open_time": "",
//         "food_type": "",
//         "close_time": "",
//         "distance": "0.0",
//         "latitude": "0.0",
//         "longitude": "0.0",
//         "discount_percentage": "",
//         "discount_type": "",
//         "discount_value": "",
//         "is_restaurant_type": "",
//         "discount_amount": "0",
//         "order_type": "",
//         "type": "",
//         "minimum_amount": "",
//         "valid_to": "",
//         "valid_date": "",
//         "description": "",
//         "maxmum_amount": "",
//         "selectedData": "",
//         "hash_id": "",
//         "bookig_date": "",
//         "bookig_time": "",
//         "booking_type": "",
//         "payable_amount": "",
//         "no_gest": "",
//         "group_type": "",
//         "username": "",
//         "phone": "",
//         "created_at": "",
//         "title": "",
//         "message": "",
//         "status": "",
//         "amount": "",
//         "store": {
//           "name": "",
//           "id": "",
//           "is_restaurant_type": "",
//           "image": "",
//           "latitude": "",
//           "longitude": "",
//           "mobile": "",
          
//         }
//       }
//     ]
//   }
