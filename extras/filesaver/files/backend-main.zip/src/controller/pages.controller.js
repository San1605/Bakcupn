const db = require("../models");
const Pages = db.pages;

exports.findOne = async (req, res) => {
    try {
        if(!req.query.slug){
            res.status(200).json({ status: false, message: "something went worng", data: {} });
        }
        let PagesCollection = await Pages.findOne({
            where: { 
                slug : req.query.slug
            }
        });
        res.status(200).json({ status: true, message: "Data get successfully", data: PagesCollection });
    } catch (error) {
        res.status(200).json({ status: false, message: "something went worng", data: {} });
    }
};
