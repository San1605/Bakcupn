/* const { cart_items } = require("../models");*/
const { response } = require("express");
const db = require("../models");
const Carts = db.carts;
const CartsItems = db.cart_items;
const User = db.user;
const Stores = db.stores;
const Storeproducts = db.store_products;
const Products = db.products;
const StoreDiscount = db.store_discounts;


exports.addToCart = async (req, res) => {
    try {
        let user = await User.findOne({ where: { phone: req.user } });
        await Carts.findOne({
            where: {
                store_id: req.body.store_id,
                user_id: user.id,
            }
        }).then(async (data) => {
            if (data == null) {
                await Carts.create({
                    store_id: req.body.store_id,
                    user_id: user.id,
                }).then(async (cart_data) => {
                    await CartsItems.create({
                        cart_id: cart_data.id,
                        store_product_id: req.body.store_product_id,
                        product_id: req.body.product_id,
                        order_type: req.body.order_type,
                        quantity: req.body.quantity
                    });
                    return res.status(200).json({ status: true, message: `Product add successfuly`, data: [] });
                })
            } else {
                await CartsItems.findOne({
                    where: {
                        cart_id: data.id,
                        product_id: req.body.product_id,
                        order_type: req.body.order_type,
                    }
                }).then(async (cart_item) => {
                    if (cart_item == null) {
                        await CartsItems.create({
                            cart_id: data.id,
                            store_product_id: req.body.store_product_id,
                            product_id: req.body.product_id,
                            order_type: req.body.order_type,
                            quantity: req.body.quantity
                        });
                        return res.status(200).json({ status: true, message: `Product add successfuly`, data: [] });
                    } else {
                        let total_quanity = cart_item.quantity + req.body.quantity;
                        await CartsItems.update({
                            quantity: total_quanity
                        }, { where: { id: cart_item.id } });
                        return res.status(200).json({ status: true, message: `Cart Update successfuly`, data: [] });
                    }
                })
            }
        }).catch((error) => {
            return res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: [] });
        })
    } catch (error) {
        return res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: [] });
    }
};

exports.myCart = async (req, res) => {
    let user = await User.findOne({ where: { phone: req.user } });
    var store_discount = 0;
    await Carts.findOne({
        include: {
            model: Stores,
        },
        where: {
            user_id: user.id,
        }
    }).then(async (cart_details) => {
        if (cart_details == null) {
            return res.status(200).json({ status: true, message: `Cart Empty`, data: [] });
        }
        store_discount = cart_details.store_id;
        await CartsItems.findAll({
            include: {
                model: Storeproducts,
            },
            where: {
                cart_id: cart_details.id
            },
        }).then(async (cart_items_roducts) => {
            var cart_item_details = cart_items_roducts;
            for (var i in cart_item_details) {
                var products_data = await Products.findOne({
                    where: {
                        id: cart_item_details[i].product_id
                    }
                });
                cart_item_details[i] = cart_item_details[i].toJSON();
                cart_item_details[i].products_data = products_data;
            }

            let StoreDiscountData = await StoreDiscount.findOne({
                where: {
                    store_id: store_discount,
                    status: true
                },
            });

            cart_details = cart_details.toJSON();
            cart_details.cart_item_details = cart_item_details;
            cart_details.store_discount = StoreDiscountData;
            return res.status(200).json({ status: true, message: `Cart Items`, data: cart_details });
        }).catch((error) => {
            return res.status(200).json({ status: false, message: `Something went worng ${error.message}`, data: [] });
        })
    }).catch((error) => {
        return res.status(200).json({ status: false, message: `Something went worng`, data: [] });
    })
}

exports.removeCartProduct = async (req, res) => {
    try {
        let user = await User.findOne({ where: { phone: req.user } });
        await Carts.findOne({
            where: {
                store_id: req.body.store_id,
                user_id: user.id,
            }
        }).then(async (response) => {
            await CartsItems.findOne({
                where: {
                    cart_id: response.id,
                    product_id: req.body.product_id,
                    order_type: req.body.order_type,
                }
            }).then(async (data) => {
                let check_quanity = data.quantity;
                console.log("data", data.id);
                if (check_quanity > 1) {
                    const response = await CartsItems.update(
                        { quantity: data.quantity - 1 },
                        {
                            where:
                            {
                                id: data.id,
                            }
                        });
                    return res.status(200).json({ status: true, message: `Cart Update successfully`, data: [] });
                } else {
                    await CartsItems.destroy({
                        where: {
                            id: data.id,
                        }
                    })
                    return res.status(200).json({ status: true, message: `Cart Deleted successfully`, data: [] });
                }
            })
        }).catch((error) => {
            return res.status(200).json({ status: false, message: `Cart id is required ${error.message}`, data: [] });
        })
    } catch (error) {
        return res.status(200).json({ status: false, message: `Cart id is required ${error.message}`, data: [] });
    }
}

exports.clearCart = async (req, res) => {
    try {
        let user = await User.findOne({ where: { phone: req.user } });
        await Carts.findOne({
            where: {
                user_id: user.id,
            }
        }).then(async(data) => {
            if(data.id == null){
                return res.status(200).json({ status: true, message: `clear cart successfully`, data: [] });
            }
            await CartsItems.destroy({
                where: {
                    cart_id: data.id,
                }
            });
            await Carts.destroy({
                where: {
                    user_id: user.id,
                }
            });
            return res.status(200).json({ status: true, message: `clear cart successfully`, data: [] });
        })
    } catch (error) {
        return res.status(200).json({ status: false, message: `error ${error.message}`, data: [] });
    }
}