const db = require("../models");
const Ratings = db.ratings;
const User = db.user;

exports.addUserRating = async (req, res) => {
    try {
        let user = await User.findOne({ where: { phone: req.user } });
        await Ratings.create({
            store_id: req.body.store_id,
            store_comment: req.body.store_comment,
            rating_value: req.body.rating_value,
            user_id: user.id
        });
        return res.status(200).json({ status: true, message: "rating successfully submitted", data: [] });
    } catch (error) {
        return res.status(200).json({ status: false, message: `${error.message}`, data: [] });
    }
};
