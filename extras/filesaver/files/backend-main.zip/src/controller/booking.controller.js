const db = require("../models");
const TableBooking = db.table_bookings;
const User = db.user;
const Transaction = db.transaction;
const Stores = db.stores;
const StoreRoutes = db.store_routes;
const Notification = db.notification;
const OrderBooking = db.order_bookings;
const BookingProducts = db.booking_products;
const Products = db.products;
const Storeproducts = db.store_products;
const Op = db.Sequelize.Op;
const axios = require('axios');

/* push notification */
const {
    senPushNotificaiton,
    sendNotifications
} = require("../utils/sendNotifications");

exports.tableBooking = async (req, res) => {
    try {
        let genRanHex = '#' + Math.floor(Math.random() * 1000000000);
        let user = await User.findOne({ where: { phone: req.user } });
        await TableBooking.create({
            store_id: req.body.store_id,
            bookig_date: req.body.bookig_date,
            bookig_time: req.body.bookig_time,
            booking_type: req.body.booking_type,
            no_gest: req.body.no_gest,
            group_type: req.body.group_type,
            username: req.body.username,
            phone: req.body.phone,
            email: req.body.email,
            transaction_id: req.body.transaction_id,
            user_id: user.id,
            hash_id: genRanHex,
        }).then(async (response) => {
            let booking_type = req.body.booking_type;

            let user_id = user.id;
            let store_id = req.body.store_id;
            let title = "Table Booking Done";
            let store_data = await Stores.findOne({
                where: { id: store_id },
            });
            let message = `Table booking done in ${store_data.name} restaurant go on time and enjoy`;
            var message_data = JSON.stringify({
                "user_id": store_data.user_id,
                "title": "Table Booking",
                "body": `New Table Booking`
            });
            var config = {
                method: 'post',
                url: 'http://3.109.44.142/api/web_notification',
                headers: {
                    'Content-Type': 'application/json'
                },
                data: message_data
            };

            if (booking_type == "Paid") {
                Transaction.create({
                    relation_id: response.id,
                    transaction_id: req.body.transaction_id,
                    paytm_order_id: req.body.paytm_order_id,
                    amount: req.body.amount,
                    booking_type: "table",
                    payment_mode: "online",
                    store_id: store_id,
                    user_id: user_id,
                    transaction_date: new Date().toISOString().slice(0, 10),
                    payment_type: "credit"
                }).then((data) => {
                    senPushNotificaiton(user_id, store_id, title, message, response.id);
                    axios(config)
                        .then(function (response) {
                            console.log(JSON.stringify(response.data));
                        })
                        .catch(function (error) {
                            console.log(error);
                        });
                    return res.status(200).json({ status: true, message: `Table Booking Successfully Created`, data: [response] });
                }).catch((error) => {
                    return res.status(200).json({ status: true, message: `something went wrong ${error.message}`, data: [] });
                })
            } else {
                senPushNotificaiton(user_id, store_id, title, message, response.id);
                axios(config)
                    .then(function (response) {
                        console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
                return res.status(200).json({ status: true, message: `Table Booking Successfully Created`, data: [response] });
            }
        }).catch((error) => {
            return res.status(200).json({ status: false, message: `something went wrong ${error.message}`, data: [] });
        })
    } catch (error) {
        return res.status(200).json({ status: false, message: `something went wrong ${error.message}`, data: [] });
    }
};

exports.bookingList = async (req, res) => {
    let user = await User.findOne({ where: { phone: req.user } });
    /* order_status = 1 : Pending, 2 :  Accept, Cancel User : 3, */
    if (req.params.order_status == 1) {
        var order_status = "Pending";
        var table_status = "Pending";
    } else if (req.params.order_status == 2) {
        var order_status = "Accept";
        var table_status = "accept";
    } else if (req.params.order_status == 3) {
        var order_status = "Cancel User";
        var table_status = "Cancel User";
    } else if (req.params.order_status == 4) {
        var order_status = "complete";
        var table_status = "Accept";
    }

    await TableBooking.findAll({
        include: {
            model: Stores,
            attributes: ['id', 'name']
        },
        where: {
            user_id: user.id,
            status: table_status,
        },
        order: [
            ['id', 'DESC'],
        ],
    })
        .then(async (data) => {

            var order_bookings = await OrderBooking.findAll({
                include: {
                    model: Stores,
                    attributes: ['id', 'name']
                },
                where: {
                    user_id: user.id,
                    status: order_status,
                },
                order: [
                    ['id', 'DESC'],
                ],
            });
            var merged = [...new Set([...data, ...order_bookings])];
            return res.status(200).json({ status: true, message: "data get successfully", data: merged });
        })
        .catch(err => {
            return res.status(200).json({ status: false, message: `something went worng ${err}`, data: {} });
        });
}

exports.bookingDetails = async (req, res) => {
    let user = await User.findOne({ where: { phone: req.user } });
    if (req.query.booking_type == 'order') {
        await OrderBooking.findOne({
            include: {
                model: Stores,
                attributes: ['id', 'name', 'latitude', 'longitude', 'mobile']
            },
            where: {
                id: req.params.booking_id,
            },
        }).then(async (data) => {

            const route_details = await Stores.findOne({
                include: {
                    model: StoreRoutes,
                    attributes: ['id', 'name']
                },
                where: {
                    id: data.store_id
                },
                attributes: ['id']
            });

            var product_details = await BookingProducts.findAll({
                include: {
                    model: Products,
                    attributes: ['id', 'name', 'amount']
                },
                where: {
                    order_booking_id: data.id
                },
                raw: true,
                nest: true,
            });

            /* for product images */
            await Promise.all(product_details.map(async (products) => {
                var store_product_data = await Storeproducts.findOne({
                    where: {
                        store_id: data.store_id,
                        product_id: products.product_id
                    },
                    attributes: ['images']
                });
                products.image = store_product_data.images
            }));

            data = data.toJSON();
            data.route_details = route_details;
            data.product_details = product_details;
            res.status(200).json({ status: true, message: `Data get successfully`, data: data })
        })
            .catch(err => res.status(200).json({ status: false, message: `something went worng ${err.message}`, data: {} }));
    } else {
        await TableBooking.findOne({
            include: {
                model: Stores,
                attributes: ['id', 'name', 'latitude', 'longitude', 'mobile']
            },
            where: {
                id: req.params.booking_id,
            },
        }).then(async (data) => {
            if (data.length === 0) {
                return res.status(200).json({ status: false, message: "No Booking Found", data: [] });
            } else {
                if (data.booking_type == "Paid") {

                    const transaction_details = await Transaction.findOne({
                        where: {
                            relation_id: data.id
                        }
                    });

                    const route_details = await Stores.findOne({
                        include: {
                            model: StoreRoutes,
                            attributes: ['id', 'name']
                        },
                        where: {
                            id: data.store_id
                        },
                        attributes: ['id']
                    });

                    data = data.toJSON();
                    data.transaction = transaction_details;
                    data.route_details = route_details;
                    return res.status(200).json({ status: true, message: "data get successfully", data: data });
                } else {
                    return res.status(200).json({ status: true, message: "data get successfully", data: data });
                }
            }
        }).catch(err => res.status(200).json({ status: false, message: `something went worng ${err.message}`, data: {} }));
    }
}

exports.bookingCancel = async (req, res) => {
    try {
        let booking_id = req.params.booking_id;
        const response = await TableBooking.update(
            { status: "Cancel User" },
            { where: { id: booking_id } });
        if (response == 1) {
            let user = await User.findOne({ where: { phone: req.user } });
            let booking_details = await TableBooking.findOne({ where: { id: booking_id } });
            let store_data = await Stores.findOne({
                where: { id: booking_details.store_id },
            });
            let title = `Cancel Table Booking`;
            let message = `Table booking cancelled in ${store_data.name} by ${user.name == null ? req.user : user.name}`;
            sendNotifications(user.id, booking_details.store_id, title, message)
            return res.status(200).json({ status: true, message: `Cancel Table Booking`, data: [] });
        } else {
            return res.status(200).json({ status: true, message: `error in cancel`, data: [] });
        }
    } catch (error) {
        return res.status(200).json({ status: true, message: `error in catch ${error.message}`, data: [] });
    }
}

exports.myNotification = async (req, res) => {
    let user = await User.findOne({ where: { phone: req.user } });
    await Notification.findAll({
        where: {
            user_id: user.id,
        },
        order: [
            ['id', 'DESC'],
        ],
    })
        .then(data => {
            if (data.length === 0) {
                return res.status(200).json({ status: true, message: "No Booking Found", data: [] });
            } else {
                return res.status(200).json({ status: true, message: "data get successfully", data: data });
            }
        })
        .catch(err => {
            return res.status(200).json({ status: false, message: `something went worng ${err}`, data: {} });
        });
}

exports.bookingStatus = async (req, res) => {
    let user = await User.findOne({ where: { phone: req.user } });
    let utc = new Date().toJSON().slice(0, 10).replace(/-/g, '-');
    /* var currentTime = new Date();
    var currentOffset = currentTime.getTimezoneOffset();
    var ISTOffset = 330;
    var ISTTime = new Date(currentTime.getTime() + (ISTOffset + currentOffset) * 60000);
    var hoursIST = ISTTime.getHours()
    var minutesIST = ISTTime.getMinutes()
    var secondsIST = ISTTime.getSeconds(); 
    var time = hoursIST + ":" + minutesIST + ":" + secondsIST;*/
    await TableBooking.findAll({
        include: {
            model: Stores,
            attributes: ['id', 'name', 'is_restaurant_type', 'image']
        },
        where: {
            user_id: user.id,
            status: 'Accept',
            bookig_date: {
                [Op.gte]: utc,
            },
        },
        order: [
            ['id', 'DESC'],
        ],
    })
        .then(async (data) => {

            const order_bookings_status = await OrderBooking.findAll({
                include: {
                    model: Stores,
                    attributes: ['id', 'name', 'is_restaurant_type', 'image']
                },
                where: {
                    user_id: user.id,
                    status: 'accept',
                    booking_date: {
                        [Op.gte]: utc,
                    },
                },
                order: [
                    ['id', 'DESC'],
                ],
            });

            const merged = [...new Set([...data, ...order_bookings_status])];
            return res.status(200).json({ status: true, message: "data get successfully", data: merged });
        })
        .catch(err => {
            return res.status(200).json({ status: false, message: `something went worng ${err}`, data: {} });
        });
}

exports.orderBooking = async (req, res) => {
    try {
        let user = await User.findOne({ where: { phone: req.user } });
        let genRanHex = '#' + Math.floor(Math.random() * 1000000000);
        if (req.body.hash_order_id) {
            var hexid = req.body.hash_order_id;
        } else {
            var hexid = genRanHex;
        }
        await OrderBooking.create({
            user_id: user.id,
            store_id: req.body.store_id,
            route_id: req.body.route_id,
            discount_amount: req.body.discount_amount,
            table_no: req.body.table_no,
            final_amount: req.body.final_amount,
            booking_date: req.body.booking_date,
            bookig_time: req.body.bookig_time,
            payment_mode: req.body.payment_mode,
            hash_id: hexid,
            status: "pending",
            food_type: req.body.food_type,
            serverice_charges: req.body.serverice_charges,
            taxes: req.body.taxes,
            payable_amount: req.body.payable_amount,
            food_instructions: req.body.food_instructions,
            vehicle_details: req.body.vehicle_details,
            username: req.body.username,
            email: req.body.email,
            no_of_guest: req.body.no_of_guest,
            coupon: req.body.coupon,
            phone: req.body.phone,
            arrival_time: req.body.arrival_time,
            transaction_id: req.body.transaction_id
        }).then(async booking_order => {
            let booking_products = req.body.order_products;
            for (data of booking_products) {
                await BookingProducts.create({
                    order_booking_id: booking_order.id,
                    product_id: data.product_id,
                    prouct_type: data.prouct_type,
                    quantity: data.quantity,
                    amount: data.amount
                });
            }

            let user = await User.findOne({ where: { phone: req.user } });
            let store_data = await Stores.findOne({
                where: { id: req.body.store_id },
            });
            let title = `Order Booking`;
            let message = `Order booking in ${store_data.name} by ${user.name == "" ? req.user : user.name}`;
            await sendNotifications(user.id, req.body.store_id, title, message);

            /* save transaction records */
            await Transaction.create({
                relation_id: booking_order.id,
                transaction_id: req.body.transaction_id,
                paytm_order_id: req.body.paytm_order_id,
                amount: req.body.final_amount,
                booking_type: "order",
                payment_mode: "online",
                store_id: req.body.store_id,
                user_id: user.id,
                transaction_date: new Date().toISOString().slice(0, 10),
                payment_type: "credit"
            });

            return res.status(200).json({ status: true, message: `Order booking successfully created`, data: booking_order });
        }).catch(error => {
            return res.status(200).json({ status: false, message: `something went worng ${error.message}`, data: [] });
        })
    } catch (error) {
        return res.status(200).json({ status: false, message: `something went worng in catch ${error.message}`, data: [] });
    }
}

exports.orderBookingCancel = async (req, res) => {
    try {
        let booking_id = req.params.booking_id;
        const response = await OrderBooking.update(
            { status: "cancel" },
            { where: { id: booking_id } });
        if (response == 1) {
            let user = await User.findOne({ where: { phone: req.user } });
            let booking_details = await OrderBooking.findOne({ where: { id: booking_id } });
            let store_data = await Stores.findOne({
                where: { id: booking_details.store_id },
            });
            let title = `Cancel Order Booking`;
            let message = `Order booking cancelled in ${store_data.name} by ${user.name == "" ? req.user : user.name}`;
            sendNotifications(user.id, booking_details.store_id, title, message)
            return res.status(200).json({ status: true, message: `Cancel Oable Booking`, data: [] });
        } else {
            return res.status(200).json({ status: true, message: `error in cancel`, data: [] });
        }
    } catch (error) {
        return res.status(200).json({ status: true, message: `error in catch ${error.message}`, data: [] });
    }
}

exports.updateArivalTime = async (req, res) => {
    try {
        let user_data = {
            arrival_time: req.body.arrival_time
        }
        await OrderBooking.update(user_data, {
            where: { id: req.body.order_id }
        }).then(num => {
            return res.status(200).send({ status: true, message: "Booking Time Successfully Update", data: {} });
        })
            .catch(err => {
                return res.status(200).send({ status: false, message: `Something went worng please try again ${err.message}`, data: {} });
            });
    } catch (error) {
        return res.status(200).send({ status: false, message: `Something went worng please try again${error.message}`, data: {} });

    }
}

