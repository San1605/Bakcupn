const db = require("../models");
const Cities = db.cities;
const Coupons = db.coupon;
const Op = db.Sequelize.Op;

exports.list = async (req, res) => {
    let utc = new Date().toJSON().slice(0, 10).replace(/-/g, '-');
    await Coupons.findAll({
        where: {
            status: 1,
            route_id: req.params.id,
            valid_to: {
                [Op.gte]: utc,
            }
        },
    })
        .then(data => {
            if (data.length === 0) {
                return res.status(200).json({ status: false, message: "No coupon found", data: [] });
            } else {
                return res.status(200).json({ status: true, message: "coupon get successfully", data: data });
            }
        })
        .catch(err => {
            return res.status(200).json({ status: false, message: `something went worng ${err}`, data: {} });
        });
};

exports.verfiyCoupon = async (req, res) => {
    try {
        let coupon_name = req.body.coupon_name;
        let amount = req.body.amount;

        if (coupon_name == "" || coupon_name == undefined) {
            return res.status(200).json({ status: false, message: "coupon name is required", data: [] });
        }

        await Coupons.findOne({
            where: {
                name: coupon_name
            }
        }).then((response) => {
            if (response != null) {
                if (response.minimum_amount <= amount) {
                    return res.status(200).json({ status: true, message: `Coupon found`, data: [response] });
                } else {
                    return res.status(200).json({ status: false, message: `Coupon not apply your final amount should be greather than ${response.minimum_amount}`, data: [] });
                }
            }
            return res.status(200).json({ status: false, message: `Coupon not found`, data: [] });
        }).catch(() => {
            return res.status(200).json({ status: false, message: `error ${error.message}`, data: [] });
        })
    } catch (error) {
        return res.status(200).json({ status: false, message: `error ${error.message}`, data: [] });
    }
}