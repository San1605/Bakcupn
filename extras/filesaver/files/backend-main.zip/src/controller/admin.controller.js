const db = require("../models");
const dbRequest = require("../utils/dbRequest")
const format = require("pg-format");
const dbQuery = require("../../helpers/dbQuery.json");
const order_bookings = db.order_bookings;
const transactions = db.transaction;
const stores = db.stores;
const users = db.user;
const store_categories = db.store_categories; 

exports.dashboardCounts = async (req, res) => {
    let bookings = await order_bookings.findAll({attributes: ['status']})
    let totalOrders = bookings.length;
    let completedOrders = 0;
    let rejectedOrders = 0;
    bookings.forEach(element => {
        if(element.status=='accept')
        {
            completedOrders+=1;
        }
        else if(element.status=='cancel')
        {
            rejectedOrders+=1 
        }
    });
    let totalTransactions = await transactions.count()
    return res.status(200).json({
        data:{
            totalOrders:totalOrders,
            completedOrders:completedOrders,
            rejectedOrders:rejectedOrders,
            totalTransactions:totalTransactions
        }  
    })
};

exports.orders = async (req,res) => {
    const result = await stores.findAll({attributes: ['id','name']});
    res.status(200).json(result)
}

exports.viewOrders = async (req,res) => {
    let pending = []
    let accepted = []
    let completed = []
    let rejected = []

    let formattedquery = format(dbQuery.admin.viewOrders,req.query.storeId);
    let result = await dbRequest(formattedquery)
    result.forEach((elem)=>{
        if(elem.status.toLowerCase()=='pending')
        {
            pending.push({
                "id":elem.id,
                "noOfGuest":elem.no_of_guest,
                "arrivalTime":elem.arrival_time,
                "orderItem":elem.productName,
                "orderType":elem.food_type,
                "name":elem.name
            })
        }
        if(elem.status.toLowerCase()=='accept')
        {
            accepted.push({
                "id":elem.id,
                "noOfGuest":elem.no_of_guest,
                "arrivalTime":elem.arrival_time,
                "orderItem":elem.productName,
                "orderType":elem.food_type,
                "name":elem.name
            })
        }if(elem.status.toLowerCase()=='complete')
        {
            completed.push({
                "id":elem.id,
                "noOfGuest":elem.no_of_guest,
                "arrivalTime":elem.arrival_time,
                "orderItem":elem.productName,
                "orderType":elem.food_type,
                "name":elem.name
            })
        }if(elem.status.toLowerCase()=='cancel')
        {
            rejected.push({
                "id":elem.id,
                "noOfGuest":elem.no_of_guest,
                "arrivalTime":elem.arrival_time,
                "orderItem":elem.productName,
                "orderType":elem.food_type,
                "name":elem.name
            })
        }
    })
    res.status(200).json({
            pending:pending,
            accepted:accepted,
            completed:completed,
            rejected:rejected
        })
    
    // order_bookings.belongsTo(users, { foreignKey: 'user_id', as: 'u' });
    // const result = await order_bookings.findAll({
    //     attributes: ['id','no_of_guest','arrival_time','food_type','status'],
    //     include: [{
    //         model: users,
    //         attributes: ['name'],
    //         required: false,
    //     }],
    //     where:{store_id: req.query.storeId}
    // });
    // result.forEach((elem)=>{
    //     if(elem.status.toLowerCase()=='pending')
    //     {
    //         pending.push({
    //             "id":elem.id,
    //             "noOfGuest":elem.no_of_guest,
    //             "arrivalTime":elem.arrival_time,
    //             "orderItem":"",
    //             "name":elem.user.name
    //         })
    //     }
    //     if(elem.status.toLowerCase()=='accept')
    //     {
    //         accepted.push({
    //             "id":elem.id,
    //             "noOfGuest":elem.no_of_guest,
    //             "arrivalTime":elem.arrival_time,
    //             "orderItem":"",
    //             "name":elem.user.name
    //         })
    //     }if(elem.status.toLowerCase()=='complete')
    //     {
    //         completed.push({
    //             "id":elem.id,
    //             "noOfGuest":elem.no_of_guest,
    //             "arrivalTime":elem.arrival_time,
    //             "orderItem":"",
    //             "name":elem.user.name
    //         })
    //     }if(elem.status.toLowerCase()=='cancel')
    //     {
    //         rejected.push({
    //             "id":elem.id,
    //             "noOfGuest":elem.no_of_guest,
    //             "arrivalTime":elem.arrival_time,
    //             "orderItem":"",
    //             "name":elem.user.name
    //         })
    //     }
    // })
}
exports.storeCategories = async (req,res)=>{
        let formattedquery = format(dbQuery.admin.storeCategories2);
        let result = await dbRequest(formattedquery)
        // let finalData = []
        let obj = {}
        result.forEach((elem)=>{
            if(elem.storeId in obj)
            {
                if(elem.food_category_id)
                {
                    // const filteredArray = obj[elem["storeId"]]["category"].filter(obj => obj.categoryId == elem.food_category_id);
                    let product_arr = []
                    elem.productId.split(",").forEach((productId,index)=>{
                        product_arr.push({
                            productId:productId,
                            productName:elem.productName.split(",")[index],
                            half_amount:elem.half_amount.split(",")[index],
                            full_amount:elem.full_amount.split(",")[index],
                            status:elem.status.split(",")[index],
                            created_at:elem.created_at.split(",")[index]
                        })
                    })
                    obj[elem["storeId"]]["category"].push({
                        "categoryId":elem.food_category_id,
                        "categoryName":elem.categoryName,
                        "products":product_arr
                    })
                }
            }
            else
            {
                obj[elem["storeId"]]={
                    "store_id":elem.storeId,
                    "storeName":elem.storeName,
                    "category":[]
                }
                if(elem.food_category_id)
                {
                    let product_arr = []
                    elem.productId.split(",").forEach((productId,index)=>{
                        product_arr.push({
                            productId:productId,
                            productName:elem.productName.split(",")[index],
                            half_amount:elem.half_amount.split(",")[index],
                            full_amount:elem.full_amount.split(",")[index],
                            status:elem.status.split(",")[index],
                            created_at:elem.created_at.split(",")[index]
                        })
                    })
                    obj[elem["storeId"]]["category"].push({
                        "category_id":elem.food_category_id,
                        "categoryName":elem.categoryName,
                        "products":product_arr
                    })
                }
            }
        })
        // result.forEach((elem)=>{
        //     let obj = {}
        //     elem.category_id.split(",").forEach((category,index)=>{
        //         obj[category] = {
        //             category_id:category,
        //             categoryName:elem.categoryName.split(",")[index]
        //         }
        //     })
        //     finalData.push({
        //         "store_id": elem.store_id,
        //         "storeName": elem.storeName,
        //         "category": Object.values(obj)
        //     })
        // })
        res.status(200).json(Object.values(obj)) 
}

exports.addCategories = async (req,res)=>{
    let categoryName = req.body.categoryName;
    let formattedquery = format(dbQuery.admin.addCategory,categoryName,1,new Date().toISOString());
    await dbRequest(formattedquery).catch(err => reject(err));
    res.status(200).json({
        status:true,
        message:"Successfully Added Category"
    }) 
}
