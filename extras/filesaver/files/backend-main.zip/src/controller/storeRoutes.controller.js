const db = require("../models");
const Cities = db.cities;
const StoreRoutes = db.store_routes;
const Op = db.Sequelize.Op;

exports.routeList = async (req, res) => {
    var whereStatement = {};
    whereStatement.status = { [Op.like]: 1 }
    if (req.query.to)
        whereStatement.to_city_id = { [Op.like]: `%${req.query.to}%` };
    if (req.query.from)
        whereStatement.from_city_id = { [Op.like]: `%${req.query.from}%` };


    await StoreRoutes.findAll({
        where: whereStatement,
        include: [{
            model: Cities,
            as: 'from_city',
            required: false,
            attributes: ['id', 'city']
        }, {
            model: Cities,
            as: 'to_city',
            required: false,
            attributes: ['id', 'city']
        }],
    })
        .then(store_routes_data => {
            if (store_routes_data.length === 0) {
                return res.status(200).json({ status: false, message: "No route found", data: [] });
            } else {
                return res.status(200).json({ status: true, message: "route get successfully", data: store_routes_data });
            }

        })
        .catch(err => {
            return res.status(200).json({ status: false, message: `something went worng ${err}`, data: {} });
        });
};

exports.cityList = async (req, res) => {
    await Cities.findAll({
        where: {
            city: {
                [Op.like]: `%${req.params.name}%`
            }
        },
    })
        .then(data => {
            if (data.length === 0) {
                return res.status(200).json({ status: false, message: "No city found", data: [] });
            } else {
                return res.status(200).json({ status: true, message: "data get successfully", data: data });
            }

        })
        .catch(err => {
            return res.status(200).json({ status: false, message: `something went worng ${err}`, data: {} });
        });
};