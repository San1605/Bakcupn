module.exports = (sequelize, Sequelize) => {
    const Enquirers = sequelize.define("enquirers", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        name: {
            type: Sequelize.STRING,
            allowNull: true
        },
        number: {
            type: Sequelize.STRING,
            allowNull: true
        },
        created_at: {
            type: Sequelize.DATEONLY,
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: false,
            timestamps: false,
        });
    return Enquirers;
};