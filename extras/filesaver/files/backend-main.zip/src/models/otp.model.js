module.exports = (sequelize, Sequelize) => {
    const otpVerification = sequelize.define("otp_verifications", {
        phone: {
            type: Sequelize.STRING,
            allowNull: true
        },
        otp: {
            type: Sequelize.MEDIUMINT,
            allowNull: true
        },
    },
    {
        engine: 'InnoDB',
        charset: 'utf8mb4',
        
    });
    return otpVerification;
};