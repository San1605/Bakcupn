module.exports = (sequelize, Sequelize) => {
    const Feedback = sequelize.define("feedbacks", {
        title: {
            type: Sequelize.STRING,
            allowNull: true
        },
        user_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        }
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            updatedAt: `updated_at`,
            createdAt: `created_at`,
            timestamps: true,
        });
    return Feedback;
};