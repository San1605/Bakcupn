module.exports = (sequelize, Sequelize) => {
    const pay_bills = sequelize.define("pay_bills", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        user_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        route_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        hash_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        discount_amount: {
            type: Sequelize.FLOAT(10, 2),
            allowNull: true
        },
        final_amount: {
            type: Sequelize.FLOAT(10, 2),
            allowNull: true
        },
        service_charge: {
            type: Sequelize.FLOAT(10, 2),
            allowNull: true
        },
        taxes: {
            type: Sequelize.FLOAT(10, 2),
            allowNull: true
        },
        transaction_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        transaction_date: {
            type: Sequelize.DATE(3),
        },
        coupon_id: {
            type: Sequelize.STRING,
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return pay_bills;
};