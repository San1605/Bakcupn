module.exports = (sequelize, Sequelize) => {
    const Banners = sequelize.define("banners", {
        hiper_link: {
            type: Sequelize.STRING,
            allowNull: true
        },
        images: {
            type: Sequelize.STRING,
            allowNull: true
        },
        header_footer: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        is_section: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        route_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        }
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            deletedAt: `deleted_at`,
            createdAt: `created_at`,
            updatedAt: `updated_at`,
            timestamps: true,
        });
    return Banners;
};