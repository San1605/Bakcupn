module.exports = (sequelize, Sequelize) => {
    const StoreCategories = sequelize.define("store_categories", {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        category_id: {
            type: Sequelize.INTEGER,
            allowNull: false,
        },
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: false,
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return StoreCategories;
};