module.exports = (sequelize, Sequelize) => {
    const table_bookings = sequelize.define("table_bookings", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        user_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        bookig_date: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        bookig_time: {
            type: Sequelize.STRING,
            allowNull: true
        },
        booking_type: {
            type: Sequelize.ENUM,
            values: ['Free', 'Paid']
        },
        no_gest: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        group_type: {
            type: Sequelize.STRING,
            allowNull: true
        },
        username: {
            type: Sequelize.STRING,
            allowNull: true
        },
        phone: {
            type: Sequelize.STRING,
            allowNull: true
        },
        email: {
            type: Sequelize.STRING,
            allowNull: true
        },
        transaction_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        hash_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        order_type: {
            type: Sequelize.ENUM,
            values: ['table booking','Order Booking'],
            defaultValue: 'table booking',
        },
        status: {
            type: Sequelize.ENUM,
            values: ['Pending','Accept','Cancel Admin','Cancel Store Manaer','Cancel User'],
            defaultValue: 'Accept',
        },
        created_at: {
            type: Sequelize.DATE(3),
            allowNull: true,
        },
        updated_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            deletedAt: `deleted_at`,
            createdAt: `created_at`,
            updatedAt: `updated_at`,            
            timestamps: true,
        });
    return table_bookings;
};