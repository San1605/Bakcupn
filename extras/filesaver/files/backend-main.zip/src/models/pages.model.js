module.exports = (sequelize, Sequelize) => {
    const Pages = sequelize.define("pages", {
        title: {
            type: Sequelize.STRING,
            allowNull: true
        },
        slug: {
            type: Sequelize.STRING,
            allowNull: true
        },
        description: {
            type: Sequelize.STRING,
            allowNull: true
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: true
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        }
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            deletedAt: `deleted_at`,
            createdAt: `created_at`,
            updatedAt: `updated_at`,
            timestamps: true,
        });
    return Pages;
};