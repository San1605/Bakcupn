module.exports = (sequelize, Sequelize) => {
    const notifications = sequelize.define("notifications", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        user_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        is_broadcast: {
            type: Sequelize.ENUM,
            values: ['Yes', 'No'],
            defaultValue: 'No',
        },
        title: {
            type: Sequelize.STRING,
            allowNull: true
        },
        message: {
            type: Sequelize.STRING,
            allowNull: true
        },
        status: {
            type: Sequelize.ENUM,
            values: ['Active','Deleted'],
            defaultValue: 'Active',
        },
        store_status: {
            type: Sequelize.ENUM,
            values: ['Pending','Read', 'Delete'],
            defaultValue: 'Pending',
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.DATE(3),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return notifications;
};