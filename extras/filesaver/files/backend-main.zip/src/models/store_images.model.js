module.exports = (sequelize, Sequelize) => {
    const StoreImages = sequelize.define("store_images", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        images: {
            type: Sequelize.STRING,
            allowNull: true
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        }
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return StoreImages;
};