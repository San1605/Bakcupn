const config = require("../config/db.config.js");
const Sequelize = require("sequelize");
const sequelize = new Sequelize(
    config.DB,
    config.USER,
    config.PASSWORD,
    {
        host: config.HOST,
        dialect: config.dialect,
        operatorsAliases: 0,

        pool: {
            max: config.pool.max,
            min: config.pool.min,
            acquire: config.pool.acquire,
            idle: config.pool.idle
        }
    }
);


sequelize
    .authenticate()
    .then(() => {
        console.log('Connection has been established successfully.');
    })
    .catch(err => {
        console.error('Unable to connect to the database:', err);
    });
/********************************************************************************* */

// connection.query('Select * from cart_items',(error, results, fields) => {
//     if(error)
//     {
//         console.log(error)
//     }
//     else
//     {
//         console.log(results)
//     }
// })
// const executeQuery = async (query) => {
//   try {
//     const connectionPromise = new Promise((resolve, reject) => {
//       connection.query(query, (error, results, fields) => {
//         if (error) reject(error);
//         resolve(results);
//       });
//     });

//     const results = await connectionPromise;
//     console.log('Query results:', results);
//   } catch (error) {
//     console.error('Error executing query:', error);
//   } finally {
//     connection.end();
//   }
// };

// // Call the executeQuery function
// executeQuery('SELECT * FROM your_table');

/*********************************************************************************** */

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.user = require("./user.model.js")(sequelize, Sequelize);
db.otp = require("./otp.model")(sequelize, Sequelize);
db.pages = require("./pages.model")(sequelize, Sequelize);
db.feedbacks = require("./feedback.model")(sequelize, Sequelize);
db.cities = require("./cities.model")(sequelize, Sequelize);
db.store_routes = require("./storeRoutes.model")(sequelize, Sequelize);
db.banners = require("./banner.model")(sequelize, Sequelize);
db.stores = require("./store.model")(sequelize, Sequelize);
db.store_discounts = require("./storeDiscount.model")(sequelize, Sequelize);
db.store_categories = require("./storeCategories.model")(sequelize, Sequelize);
db.store_images = require("./store_images.model")(sequelize, Sequelize);
db.store_products = require("./store_products.model")(sequelize, Sequelize);
db.product_categories = require("./product_categories.model")(sequelize, Sequelize);
db.products = require("./products.model")(sequelize, Sequelize);
db.coupon = require("./coupon.model")(sequelize, Sequelize);
db.table_bookings = require("./table_bookings.model")(sequelize, Sequelize);
db.transaction = require("./transaction.model")(sequelize, Sequelize);
db.notification = require("./notification.model")(sequelize, Sequelize);
db.carts = require("./carts.model")(sequelize, Sequelize);
db.cart_items = require("./cart_items.model")(sequelize, Sequelize);
db.order_bookings = require("./order_bookings.model")(sequelize, Sequelize);
db.booking_products = require("./booking_products.model")(sequelize, Sequelize);
db.ratings = require("./ratings.model")(sequelize, Sequelize);
db.enquirers = require("./enquirers.model")(sequelize, Sequelize);
db.pay_bills = require("./pay_bills.model")(sequelize, Sequelize);
db.hotel_facilities = require("./hotel_facilities.model")(sequelize, Sequelize);

sequelize.models.store_routes.belongsTo(sequelize.models.cities, {
    foreignKey: "from_city_id",
    targetKey: "id",
    as: 'from_city'
});

sequelize.models.store_routes.belongsTo(sequelize.models.cities, {
    foreignKey: "to_city_id",
    targetKey: "id",
    as: 'to_city'
});

sequelize.models.store_products.belongsTo(sequelize.models.product_categories, {
    foreignKey: "food_category_id",
    targetKey: "id",
});

sequelize.models.store_products.belongsTo(sequelize.models.products, {
    foreignKey: "product_id",
    targetKey: "id",
});

sequelize.models.table_bookings.belongsTo(sequelize.models.stores, {
    foreignKey: "store_id",
    targetKey: "id",
});

sequelize.models.order_bookings.belongsTo(sequelize.models.stores, {
    foreignKey: "store_id",
    targetKey: "id",
});

sequelize.models.stores.belongsTo(sequelize.models.store_routes, {
    foreignKey: "route_id",
    targetKey: "id",
});

sequelize.models.carts.belongsTo(sequelize.models.stores, {
    foreignKey: "store_id",
    targetKey: "id",
});

sequelize.models.cart_items.belongsTo(sequelize.models.store_products, {
    foreignKey: "store_product_id",
    targetKey: "id",
});

sequelize.models.booking_products.belongsTo(sequelize.models.products, {
    foreignKey: "product_id",
    targetKey: "id",
});

sequelize.models.ratings.belongsTo(sequelize.models.users, {
    foreignKey: "user_id",
    targetKey: "id",
});
sequelize.models.order_bookings.belongsTo(sequelize.models.users, {
    foreignKey: "user_id",
    targetKey: "id",
});
// order_bookings.belongsTo(users, { foreignKey: 'user_id', as: 'u' });
module.exports = db;