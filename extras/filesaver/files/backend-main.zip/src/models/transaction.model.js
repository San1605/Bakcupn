module.exports = (sequelize, Sequelize) => {
    const transaction = sequelize.define("transactions", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        user_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        payment_mode: {
            type: Sequelize.ENUM,
            values: ["cash", "online"],
        },
        transaction_date: {
            type: Sequelize.DATE(3),
        },
        transaction_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        paytm_order_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        relation_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        booking_type: {
            type: Sequelize.ENUM,
            values: ["table", "order", "pay bill"],
        },
        amount: {
            type: Sequelize.FLOAT(10, 6),
            allowNull: true
        },
        payment_type: {
            type: Sequelize.ENUM,
            values: ["credit", "debit"],
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return transaction;
};