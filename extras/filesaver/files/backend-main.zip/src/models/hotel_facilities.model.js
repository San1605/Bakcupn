module.exports = (sequelize, Sequelize) => {
    const hotel_facilities = sequelize.define("hotel_facilities", {
        name: {
            type: Sequelize.STRING,
            allowNull: true
        },
        created_at: {
            type: Sequelize.DATEONLY,
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: false,
            timestamps: false,
        });
    return hotel_facilities;
};