module.exports = (sequelize, Sequelize) => {
    const order_bookings = sequelize.define(
        "order_bookings",
        {
            store_id: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            user_id: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            route_id: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            discount_amount: {
                type: Sequelize.FLOAT(10, 6),
                allowNull: true,
            },
            table_no: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            final_amount: {
                type: Sequelize.FLOAT(10, 6),
                allowNull: true,
            },
            booking_date: {
                type: Sequelize.DATE(3),
                allowNull: true
            },
            bookig_time: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            payment_mode: {
                type: Sequelize.ENUM,
                values: ["cash", "online"],
            },
            status: {
                type: Sequelize.ENUM,
                values: ["pending", "cancel", "accept", "deny", "complete"],
                defaultValue: "pending",
            },
            transaction_id: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            hash_id: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            created_at: {
                type: Sequelize.DATE(3),
                allowNull: true,
            },
            updated_at: {
                type: Sequelize.DATE(3),
                allowNull: true,
            },
            deleted_at: {
                type: Sequelize.DATE(3),
                allowNull: true,
            },
            food_type: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            serverice_charges: {
                type: Sequelize.FLOAT(10, 6),
                allowNull: true,
            },
            taxes: {
                type: Sequelize.FLOAT(10, 6),
                allowNull: true,
            },
            payable_amount: {
                type: Sequelize.FLOAT(10, 6),
                allowNull: true,
            },
            food_instructions: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            vehicle_details: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            username: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            email: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            no_of_guest: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            coupon: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            phone: {
                type: Sequelize.STRING,
                allowNull: true,
            },
            arrival_time: {
                type: Sequelize.STRING,
                allowNull: true,
            },
        },
        {
            engine: "InnoDB",
            charset: "utf8mb4",
            paranoid: true,
            deletedAt: `deleted_at`,
            createdAt: `created_at`,
            updatedAt: `updated_at`,
            timestamps: false,
        }
    );
    return order_bookings;
};
