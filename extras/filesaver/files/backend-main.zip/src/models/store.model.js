module.exports = (sequelize, Sequelize) => {
    const Stores = sequelize.define("stores", {
        user_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        name: {
            type: Sequelize.STRING,
            allowNull: true
        },
        mobile: {
            type: Sequelize.STRING,
            allowNull: true
        },
        address: {
            type: Sequelize.STRING,
            allowNull: true
        },
        is_postion: {
            type: Sequelize.BOOLEAN,
            allowNull: true
        },
        is_celebration: {
            type: Sequelize.BOOLEAN,
            allowNull: true
        },
        route_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        description: {
            type: Sequelize.STRING,
            allowNull: true
        },
        open_time: {
            type: Sequelize.STRING,
            allowNull: true
        },
        close_time: {
            type: Sequelize.STRING,
            allowNull: true
        },
        admin_status: {
            type: Sequelize.BOOLEAN,
            allowNull: true
        },
        google_address: {
            type: Sequelize.STRING,
            allowNull: true
        },
        is_room: {
            type: Sequelize.BOOLEAN,
            allowNull: true
        },
        is_restaurant_type: {
            type: Sequelize.BOOLEAN,
            allowNull: true
        },
        facilities: {
            type: Sequelize.JSON,
            allowNull: true
        },
        // take_away: {
        //     type: Sequelize.BOOLEAN,
        //     allowNull: true
        // },
        // air_condition: {
        //     type: Sequelize.BOOLEAN,
        //     allowNull: true
        // },
        // clean_washroom: {
        //     type: Sequelize.BOOLEAN,
        //     allowNull: true
        // },
        // outdoor_seating: {
        //     type: Sequelize.BOOLEAN,
        //     allowNull: true
        // },
        // hygienic_food: {
        //     type: Sequelize.BOOLEAN,
        //     allowNull: true
        // },
        // supporting_staff: {
        //     type: Sequelize.BOOLEAN,
        //     allowNull: true
        // },
        room_details: {
            type: Sequelize.STRING,
            allowNull: true
        },
        video_link: {
            type: Sequelize.STRING,
            allowNull: true
        },
        latitude: {
            type: Sequelize.FLOAT(10, 6),
            allowNull: true
        },
        longitude: {
            type: Sequelize.FLOAT(10, 6),
            allowNull: true
        },
        is_prime: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        packing_charges: {
            type: Sequelize.FLOAT(10, 2),
            allowNull: true
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        image: {
            type: Sequelize.STRING,
            allowNull: true
        },
        is_category: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        }
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return Stores;
};