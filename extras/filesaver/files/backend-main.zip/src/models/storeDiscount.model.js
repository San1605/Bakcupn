module.exports = (sequelize, Sequelize) => {
    const StoreDiscount = sequelize.define("store_discounts", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        discount_type: {
            type: Sequelize.ENUM,
            values: ["fixed", "percentage"],
        },
        discount_percentage: {
            type: Sequelize.DECIMAL(10,2),
            allowNull: true
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        }
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return StoreDiscount;
};