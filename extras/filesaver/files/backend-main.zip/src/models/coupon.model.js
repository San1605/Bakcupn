module.exports = (sequelize, Sequelize) => {
    const Coupon = sequelize.define("coupons", {
        route_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        name: {
            type: Sequelize.STRING,
            allowNull: true
        },
        discount_amount: {
            type: Sequelize.FLOAT(10, 6),
            allowNull: true
        },
        type: {
            type: Sequelize.ENUM,
            values: ['Fixed amount', 'Percentage']
        },
        minimum_amount: {
            type: Sequelize.FLOAT(10, 6),
            allowNull: true
        },
        maxmum_amount: {
            type: Sequelize.FLOAT(10, 6),
            allowNull: true
        },
        valid_to: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        valid_date: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        description: {
            type: Sequelize.STRING,
            allowNull: true
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return Coupon;
};