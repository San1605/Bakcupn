module.exports = (sequelize, Sequelize) => {
    const ratings = sequelize.define("ratings", {
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        user_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        store_comment: {
            type: Sequelize.STRING,
            allowNull: true
        },
        rating_value: {
            type: Sequelize.FLOAT(10, 6),
            allowNull: true,
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return ratings;
};