module.exports = (sequelize, Sequelize) => {
    const Carts = sequelize.define("carts", {
        user_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        store_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        status: {
            type: Sequelize.ENUM,
            values: ['Active','Destroy'],
            defaultValue: 'Active',
        },
        created_at: {
            type: Sequelize.DATE(3),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
        deleted_at: {
            type: Sequelize.DATE(3),
            allowNull: true
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            deletedAt: `deleted_at`,
            createdAt: `created_at`,
            updatedAt: `updated_at`,
            paranoid: false,
            timestamps: true,
        });
    return Carts;
};