module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("users", {
        name: {
            type: Sequelize.STRING,
            allowNull: true
        },
        email: {
            type: Sequelize.STRING,
            allowNull: true
        },
        phone: {
            type: Sequelize.STRING,
            allowNull: true
        },
        email_verified_at: {
            type: Sequelize.STRING,
            allowNull: true
        },
        role_id: {
            type: Sequelize.STRING,
            allowNull: true
        },
        password: {
            type: Sequelize.STRING,
            allowNull: true
        },
        remember_token: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        deviceToken: {
            type: Sequelize.STRING,
            allowNull: true
        },
        deviceType: {
            type: Sequelize.STRING,
            allowNull: true
        },
        traveller_type: {
            type: Sequelize.STRING,
            allowNull: true
        },
        travel_mode: {
            type: Sequelize.STRING,
            allowNull: true
        },
        imei_number: {
            type: Sequelize.STRING,
            allowNull: true
        },
        device_name : {
            type: Sequelize.STRING,
            allowNull: true
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: 1
        },
        created_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        },
        updated_at: {
            type: Sequelize.DATE(3),
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(3)'),
        }
    },
    {
        engine: 'InnoDB',
        charset: 'utf8mb4',
        paranoid: true,
        timestamps: false,
    });
    return User;
};