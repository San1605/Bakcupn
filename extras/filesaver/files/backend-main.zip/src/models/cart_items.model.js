module.exports = (sequelize, Sequelize) => {
    const cart_items = sequelize.define("cart_items", {
        cart_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        product_id: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
        store_product_id: {
            type: Sequelize.INTEGER(11),
        },
        order_type: {
            type: Sequelize.ENUM,
            values: ['Half','Full'],
            defaultValue: 'Half',
        },
        quantity: {
            type: Sequelize.INTEGER,
            allowNull: true
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            paranoid: true,
            timestamps: false,
        });
    return cart_items;
};