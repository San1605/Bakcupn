module.exports = (sequelize, Sequelize) => {
    const City = sequelize.define("cities", {
        city: {
            type: Sequelize.STRING,
            allowNull: true
        },
        State: {
            type: Sequelize.STRING,
            allowNull: true
        },
    },
        {
            engine: 'InnoDB',
            charset: 'utf8mb4',
            timestamps: false,
        });
    return City;
};