module.exports = (sequelize, Sequelize) => {
    const booking_products = sequelize.define(
        "booking_products",
        {
            order_booking_id: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            product_id: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            prouct_type: {
                type: Sequelize.ENUM,
                values: ["Half", "Full"],
            },
            quantity: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            amount: {
                type: Sequelize.FLOAT(10, 6),
                allowNull: true,
            },
        },
        {
            engine: "InnoDB",
            charset: "utf8mb4",
            timestamps: false,
        }
    );
    return booking_products;
};
