const db = require("../models");
const Notification = db.notification;
const User = db.user;

const FCM = require('fcm-node');
const serverKey = process.env.FIREBASE_KEY;
const fcm = new FCM(serverKey);

const axios = require('axios');

const senPushNotificaiton = async (user_id, store_id, title, message, booking_id) => {
    try {
        Notification.create({
            user_id,
            store_id,
            title,
            message,
        }).then(async (data) => {
            let user_data = await User.findOne({
                where: { id: user_id },
            });
            var message_data = {
                to: user_data.deviceToken,
                notification: {
                    title: title,
                    body: message,
                    sound: true,
                },

                data: {
                    title: title,
                    body: `${message}`,
                    data: `{"order_id" : ${booking_id}}`,
                }
            };

            fcm.send(message_data, function (err, response) {
                if (err) {
                    console.log("Something has gone wrong!" + err);
                    console.log("Respponse:! " + response);
                } else {
                    console.log("Successfully sent with response: ", response);
                }
            });
            return { status: true, message_data: `send notification is successfully`, data: [] }
        }).catch((error) => {
            return { status: false, message_data: `error while send notification is ${error.message}`, data: [] }
        })
    } catch (error) {
        return { status: false, message_data: `error is ${error.message}`, data: [] }
    }
};

const sendNotifications = async (user_id, store_id, title, message) => {
    try {
        Notification.create({
            user_id,
            store_id,
            title,
            message,
        }).then(async (data) => {
            return data;
            //return res.status(200).json({ status: true, message: `send notification is successfully`, data: [] });
        }).catch((error) => {
            return error;
            //return res.status(201).json({ status: false, message: `error while send notification is ${error.message}`, data: [] });
        })
    } catch (error) {
        return res.status(201).json({ status: false, message: `error is ${error.message}`, data: [] });
    }
}

const sendWebushNotification = async (user_id, message) => {
    try {
        var message_data = JSON.stringify({
            "user_id": user_id,
            "title": "Booking Notification",
            "body": message
        });
        var config = {
            method: 'post',
            url: 'http://3.109.44.142/api/web_notification',
            headers: {
                'Content-Type': 'application/json'
            },
            data: message_data
        };
        axios(config)
            .then(function (response) {
                console.log(JSON.stringify(response.data));
            })
            .catch(function (error) {
                console.log(error);
            });
        return true
    } catch (error) {
        return res.status(201).json({ status: false, message: `error is ${error.message}`, data: [] });
    }
}

module.exports = {
    senPushNotificaiton,
    sendNotifications,
    sendWebushNotification
};



