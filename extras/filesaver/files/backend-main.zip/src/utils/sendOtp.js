const db = require("../models");
const otpVerification = db.otp;
const axios = require('axios');
const sendOtp = async (mobile_number) => {
  let motp = await Math.floor(1000 + Math.random() * 9000);

  let message = `${motp}  is your OTP for login to Hiway Food app. Valid for 2 minutes. Do not share your OTP with anyone. Good Food Good Mood. nzcvp/pQKAj
Regards HiWayFood Team`; 
  let decode_message = encodeURI(message);
  var config = {
    method: 'get',
    url: `http://bhashsms.com/api/sendmsg.php?user=Hiwayfood&pass=123456&sender=HiFood&phone=${mobile_number}&text=${decode_message}&priority=ndnd&stype=normal`,
    headers: { }
  };

  axios(config)
  .then(function (response) {
    console.log(JSON.stringify(response.data));
  })
  .catch(function (error) {
    console.log(error);
  });


  let  getMobileOtp = await otpVerification.findOne({ where: { phone: mobile_number} });
    if(getMobileOtp){
      await otpVerification.destroy({ where: { phone: mobile_number} });
    }
    await new otpVerification({
      phone: mobile_number,
      otp: motp,
    }).save();
    return true;
};

module.exports = {
  sendOtp
};