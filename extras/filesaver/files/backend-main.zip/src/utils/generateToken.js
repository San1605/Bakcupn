const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });
const jwt = require('jsonwebtoken');
const tokenList = {};

const secret_key = process.env.secret || "hiway@12356";
const tokenLife = process.env.tokenLife || 900;
const refreshTokenSecret = process.env.refreshTokenSecret || "hiway@12356";
const refreshTokenLife = process.env.refreshTokenLife || 900;


const generateToken = (mobile_number) => {
    const user_data = {
        "phone": mobile_number,
    }

    const token = jwt.sign({
        phone: mobile_number
    },
        secret_key, {
        expiresIn: "1hr"
    });


    const refreshToken = jwt.sign(user_data, refreshTokenSecret, { expiresIn: refreshTokenLife })
    const response = {
        "status": "Logged in",
        "token": token,
        "refreshToken": refreshToken,
    }

    tokenList[refreshToken] = response
    return response;
}

const updateToken = (mobile_number) => {
    const token = jwt.sign({
        phone: mobile_number
    },
        secret_key, {
        expiresIn: "1hr"
    });

    /* const token = jwt.sign(user_data, secret_key, { expiresIn: tokenLife }) */
    return token
}

module.exports = {
    generateToken,
    updateToken
};
