const {dbConnection,connection} = require("./dbConnection");

const dbRequest = async (query) => {
    // sending request to the database
    return new Promise((resolve, reject) => {
        try 
        {
            // request.query(query, async (err, recordset) => {
            //     if (err) {
            //         console.log(err)
            //         console.log('err')
            //         reject(err.originalError.info.message || err);
            //     } else {
            //         resolve(recordset.recordset);
            //     }
            // });
            connection.query(query, (error, results, fields) => {
                if (error) reject(error);
                resolve(results);
            });
        } catch (error) {
        reject(error.message);
      }
    });
};
module.exports = dbRequest;