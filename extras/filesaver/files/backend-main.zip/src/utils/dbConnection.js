const mysql = require('mysql');
const appRoot = require('app-root-path')
const path = require('path')
require('dotenv').config({ path: path.join(appRoot.path,'/config.env') });
const connection = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB
});
const dbConnection = () => {
    return new Promise((resolve, reject) => {
        try 
        {
            connection.connect((error) => {
                if (error) reject(error);
                resolve('Connected to MySQL database!'); 
            });
        }
        catch (error) {
            console.error('Error executing query:', error);
        }

    });
};


module.exports = {dbConnection,connection};
