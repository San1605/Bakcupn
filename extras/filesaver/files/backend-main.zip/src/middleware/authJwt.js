const jwt = require("jsonwebtoken");
const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });

verifyToken = (req, res, next) => {
  let token;

  if (req.headers["authorization"] && req.headers["authorization"].startsWith("Bearer")) {
    token = req.headers["authorization"].split(" ")[1];
    console.log(token)
  }

  if (!token) {
    return res.status(401).send({ status: false, message: "Not authorized to access this route", data: {} });
  }

  try {
    const secret_key = process.env.secret || "hiway@12356";
    jwt.verify(token, secret_key, (err, user) => {
      if (err) {
        return res.status(401).send({ status: false, message: "Token expired", data: {} });
    }
    req.user = user.phone;
    next();
    });
  } catch (error) {
    return res.status(401).send({ status: false, message: "Not authorized to access this route", data: {} });
  }
};
const authJwt = {
  verifyToken: verifyToken,
};
module.exports = authJwt;