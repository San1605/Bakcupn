export const addTodo = (data) => {
    return {
        type: "ADD_TODO",
        payload: data
    }
}

export const deleteTodo = (data)=>{
    return{
        type:"DELETE_TODO",
        payload:data
    }
}