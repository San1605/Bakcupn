import { combineReducers, legacy_createStore } from "redux";
import reducer from "./reducer";

const rootReducer = combineReducers({
    reducer
})
const store = legacy_createStore(
    rootReducer
)

export default store