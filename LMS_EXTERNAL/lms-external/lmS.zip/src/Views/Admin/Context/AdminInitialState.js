export const adminInitialState={
    lpList: [],
    collegeList: [],
    courseList: [],
    courseDetail: [],
    collegeMentors: [],
    celebalMentors: [],
    studentList: [],
    socket:{},
    communityChatArray:[],
    messageObj:{},
    selectedTabIndex:0,
    selectedTabIndexRole:0,
    courseStatusList:[],
    collegeRoleList:[]
}

