import React, { useMemo } from 'react'
import "./AdminDashBoard.css"
import TopColleges from '../../../../Components/DashboardComponents/TopColleges/TopColleges'
import UpcomingEvents from '../../../../Components/DashboardComponents/UpcomingEvents/UpcomingEvents'
import LeaderBoards from '../../../../Components/DashboardComponents/LeaderBoard/LeaderBoards'
import CollegeInformation from '../../../../Components/DashboardComponents/CollegeInformation/CollegeInformation'
import GeneralFiles from '../../../../Components/DashboardComponents/GeneralFiles/GeneralFiles'
import MostEnrolledCourses from '../../../../Components/DashboardComponents/MostEnrolledCourses/MostEnrolledCourses'
import KpiCard from '../../../../Components/KpiCard/KpiCard'
import { kpi1, kpi2, kpi3, kpi4 } from '../../Assets/adminIcons'
const AdminDashBoard = () => {
  const kpiData = useMemo(() =>
    [
      {
        metricKey: "noOfStudent",
        text: "No. of Students",
        value: 0,
        imgUrl: kpi1,
        bgColor: "#FFF4EB"
      },
      {
        metricKey: "noOfDomains",
        text: "No. of Domains",
        value: 0,
        imgUrl: kpi2,
        bgColor: "#FFF7FF"
      },
      {
        metricKey: "totalActiveCourses",
        text: "Total Active Courses",
        value: 0,
        imgUrl: kpi3,
        bgColor: "#FFFAED"
      },
      {
        metricKey: "noOfCtMentor",
        text: "No. of CT Mentors",
        value: 0,
        imgUrl: kpi4,
        bgColor: "#F4FFEE"
      },
    ]
    , [])
    
  return (
    <div className='adminDashboard'>
      <div className='KpiContainer'>
        {
          (kpiData?.length > 0 ? kpiData : kpiData)?.map((item, index) => (
            <KpiCard {...item} key={index} />
          ))
        }
      </div>
      <div className='adminDashboardPage'>
        <div className='adminDashboardLeft'>
          <TopColleges />
          <CollegeInformation />
        </div>
        <div className='adminDashboardRight'>
          <MostEnrolledCourses />
          <GeneralFiles />
        </div>
      </div>
    </div>
  )
}

export default AdminDashBoard
