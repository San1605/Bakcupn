import React, { useMemo } from 'react'
import ProgressReport from '../../../../Components/DashboardComponents/ProgressReport/ProgressReport'
import UpcomingEvents from '../../../../Components/DashboardComponents/UpcomingEvents/UpcomingEvents'
import GeneralFiles from '../../../../Components/DashboardComponents/GeneralFiles/GeneralFiles'
import StudentsDetails from '../../../../Components/DashboardComponents/StudentsDetails/StudentsDetails'
import NoticeBoard from '../../../../Components/DashboardComponents/NoticeBoard/NoticeBoard'
import { kpi1, kpi2, kpi3, kpi4 } from '../../Assets/adminIcons'
import KpiCard from '../../../../Components/KpiCard/KpiCard'

const HrBuddyDashBoard = () => {
  const kpiData = useMemo(() =>
    [
      {
        metricKey: "noOfStudent",
        text: "No. of Students",
        value: 0,
        imgUrl: kpi1,
        bgColor: "#FFF4EB"
      },
      {
        metricKey: "noOfDomains",
        text: "No. of Domains",
        value: 0,
        imgUrl: kpi2,
        bgColor: "#FFF7FF"
      },
      {
        metricKey: "totalActiveCourses",
        text: "Total Active Courses",
        value: 0,
        imgUrl: kpi3,
        bgColor: "#FFFAED"
      },
      {
        metricKey: "noOfCtMentor",
        text: "No. of CT Mentors",
        value: 0,
        imgUrl: kpi4,
        bgColor: "#F4FFEE"
      },
    ]
    , [])
  return (
    <div className='adminDashboard'>
      <div className='KpiContainer'>
        {
          (kpiData?.length > 0 ? kpiData : kpiData)?.map((item, index) => (
            <KpiCard {...item} key={index} />
          ))
        }
      </div>
      <div className='adminDashboardPage'>
        <div className='adminDashboardLeft'>
          <ProgressReport role="hrBuddy" />
          <StudentsDetails />
        </div>
        <div className='adminDashboardRight'>
          <GeneralFiles role="HrBuddy" />
          <NoticeBoard role="HrBuddy" />
        </div>
      </div>
    </div>
  )
}

export default HrBuddyDashBoard
