export const mentorInitialState = {
    courseListMentor: [],
    mentorMetrics:[],
    coursesDetailMentor:{}
}