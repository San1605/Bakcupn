
import React, { useMemo } from 'react'
import LearningPathprogress from '../../../../Components/DashboardComponents/LearningPathProgress/LearningPathprogress'
import UpcomingEvents from '../../../../Components/DashboardComponents/UpcomingEvents/UpcomingEvents'
import StudentsDetails from '../../../../Components/DashboardComponents/StudentsDetails/StudentsDetails'
import NoticeBoard from '../../../../Components/DashboardComponents/NoticeBoard/NoticeBoard'
import KpiCard from '../../../../Components/KpiCard/KpiCard'
import { kpi1, kpi2, kpi3, kpi4 } from '../../../Admin/Assets/adminIcons'
const MentorDashBoard = () => {
  const kpiData = useMemo(() =>
    [
      {
        metricKey: "noOfStudent",
        text: "No. of Students",
        value: 0,
        imgUrl: kpi1,
        bgColor: "#FFF4EB"
      },
      {
        metricKey: "noOfDomains",
        text: "No. of Active Students",
        value: 0,
        imgUrl: kpi2,
        bgColor: "#FFF7FF"
      },
      {
        metricKey: "totalActiveCourses",
        text: "Current Week",
        value: 0,
        imgUrl: kpi3,
        bgColor: "#FFFAED"
      },
      {
        metricKey: "noOfCtMentor",
        text: "Total Week",
        value: 0,
        imgUrl: kpi4,
        bgColor: "#F4FFEE"
      },
    ]
    , [])
  return (
    <div className='adminDashboard'>
      <div className='KpiContainer'>
        {
          (kpiData?.length > 0 ? kpiData : kpiData)?.map((item, index) => (
            <KpiCard {...item} key={index} />
          ))
        }
      </div>
      <div className='adminDashboardPage'>
        <div className='adminDashboardLeft'>
          <LearningPathprogress />
          <StudentsDetails />
        </div>
        <div className='adminDashboardRight'>
          <UpcomingEvents role="HrBuddy" />
          <NoticeBoard role="HrBuddy" />
        </div>
      </div>
    </div>
  )
}

export default MentorDashBoard
