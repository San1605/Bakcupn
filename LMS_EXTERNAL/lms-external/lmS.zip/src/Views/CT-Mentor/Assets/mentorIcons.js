import lockIconFill from "./Icons/lockIconFill.svg"
import lockIcon from "./Icons/lockIcon.svg"
import unLockIcon from "./Icons/unLockIcon.svg"
import statusLock from "./Icons/statusLock.svg"
import statusUnLock from "./Icons/statusUnLock.svg";

export {
    lockIconFill,
    lockIcon,
    unLockIcon,
    statusLock,
    statusUnLock
}