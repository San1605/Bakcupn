import "./UserLearnPage.css"
import Accordion from 'react-bootstrap/Accordion';
import React, { useContext, useEffect, useRef, useState } from 'react'
import { GlobalContext } from '../../../../Context/GlobalContext';
import { userActions } from '../../Context/userAction';
import toast from 'react-hot-toast';
import { useParams } from 'react-router-dom';
import ReactPlayer from 'react-player';
import Loader from '../../../../Utils/Loader/Loader'
import Sidebar from '../../../../Components/Sidebar/Sidebar';
import Navbar from '../../../../Components/Navbar/Navbar';
import { readingIcon, videoIcon, opennew, completeTick, videoIconNormal, readingIconNormal, readingIconLocked, videoIconLocked, readingImage } from "../../Assets/userIcons"

const UserLearnPage = () => {
    const { enrolledCourseInfo, dispatch, markAsComplete, getMyCurrentCourse } = useContext(GlobalContext)
    const [collapseSideBar, setCollapseSideBar] = useState(true);
    const [loading, setLoading] = useState(false)
    const [overlayState, setOverlayState] = useState(false);
    // const [isPlaying, setsIsplaying] = useState(false);
    const player = useRef(null);
    const [eventKey, setEventKey] = useState("0");
    const [isComplete, setIsComplete] = useState([]);
    const { id1 } = useParams();


    const [currentElement, setCurrentElement] = useState({});
    const [readingContent, setReadingContent] = useState("");
    const [contentType, setContentType] = useState("");
    const [subtopic, setSubtopic] = useState("");
    const [topicIndex, setTopicIndex] = useState(0);
    const [subtopicIndex, setSubtopicIndex] = useState(0);

    const handleDocumentClick = (e) => {
        if (
            !document.getElementById('sidebar')?.contains(e.target) &&
            !document.getElementById('hamburger-icon')?.contains(e.target)) {
            setTimeout(() => {
                setOverlayState(false);
            }, 300)
            setCollapseSideBar(true)
        }
    };


    const getMyCurrentCourseApi = async (courseId) => {
        setLoading(true);
        try {
            const response = await getMyCurrentCourse(courseId);
            const { topics } = response || {};

            dispatch({
                type: userActions.ENROLLED_COURSE_DATA_INFO,
                payload: response,
            });

            if (topics?.length > 0) {
                const firstTopic = topics[0];
                setCurrentElement(firstTopic?.topicData[0])
                setSubtopic(firstTopic?.topicData[0]?.subtopic || "");
                if (!firstTopic?.isLocked) {
                    setReadingContent(firstTopic?.topicData[0]?.link1 || "");
                    setContentType(firstTopic?.topicData[0]?.contentType || "");
                }
                const arr = topics.map((element) =>
                    element.topicData.map((ele) => ele?.completed)
                );
                setIsComplete(arr);
            }
        } catch (error) {
            toast.dismiss();
            toast.error(error?.message);
        } finally {
            setLoading(false);
        }
    };

    async function markAsCompleteApi(courseId, subtopicId, index, idx) {
        const toastId = toast.loading("Please wait");
        try {
            const response = await markAsComplete(courseId, subtopicId);

            if (response) {
                const updatedIsComplete = [...isComplete];
                updatedIsComplete[index][idx] = true;
                setIsComplete(updatedIsComplete);

                const ele1 = enrolledCourseInfo?.topics[index]?.topicData[idx + 1];
                const ele2 = enrolledCourseInfo?.topics[index + 1]?.topicData[0];
                const nextElement = ele1 || ele2 || null;
                if (nextElement && !nextElement?.isLocked) {
                    const nextIndex = nextElement === ele1 ? index : index + 1;
                    setEventKey(nextIndex + "");
                    setTopicIndex(nextIndex);
                    setSubtopicIndex(nextElement === ele1 ? idx + 1 : 0);

                    const { link1, link2, subtopic, contentType } = nextElement;
                    setSubtopic(subtopic);
                    setContentType(contentType);
                    setCurrentElement(nextElement);
                    setReadingContent(link1 || link2);
                }
            }
            toast.dismiss(toastId);
            toast.success(response?.data?.message);
        } catch (error) {
            console.log(error)
            toast.dismiss(toastId);
            toast.error("Something went wrong");
        } finally {
            setLoading(false);
        }
    }







    function handleClickContent(ele, index, idx) {
        const { link1, link2, contentType, subtopic } = ele;
        setReadingContent(link1 || link2);
        setCollapseSideBar(true);
        setContentType(contentType);
        setTopicIndex(index);
        setSubtopicIndex(idx);
        setCurrentElement(ele);
        setSubtopic(subtopic);
    }


    function handleMarkAsComplete() {
        if (!isComplete[topicIndex][subtopicIndex]) {
            markAsCompleteApi(id1, currentElement?.ID, topicIndex, subtopicIndex)
        }
        else {
            toast.dismiss();
            toast.error("It is already Completed")
        }
    }


    useEffect(() => {
        getMyCurrentCourseApi(id1);
        document.addEventListener("click", handleDocumentClick);
        return () => {
            document.removeEventListener("click", handleDocumentClick);
        };
    }, []);


    if (loading) {
        return <div style={{ height: "100vh", width: "100vw" }}>
            <Loader />
        </div>
    }

    return (
        <div className='userlearnPage'>
            <div className={`opacityDull ${overlayState ? "show" : "hide"}`}>
                <Sidebar
                    type="collapse"
                    setCollapseSideBar={setCollapseSideBar}
                    collapseSideBar={collapseSideBar}
                />
            </div>

            <div className='userLearnPageLayout'>
                <Navbar
                    type="collapse"
                    setCollapseSideBar={setCollapseSideBar}
                    collapseSideBar={collapseSideBar}
                    overlayState={overlayState}
                    setOverlayState={setOverlayState}
                />
                <div className='studentLearn'>
                    <div className="videoplayer">
                        <div className="videoPlayerHeading">
                            <span>{subtopic}</span>

                            {
                                isComplete?.length > 0 && isComplete[topicIndex][subtopicIndex] ?
                                    <div className="topicCompleted">Completed</div>
                                    :
                                    !currentElement?.isLocked ?
                                        <div
                                            onClick={() => handleMarkAsComplete()}
                                            className="topicNotComplete">Mark as Complete</div>
                                        : null
                            }

                        </div>
                        <div className="videoPlayerContainer">
                            {

                                contentType === 'Video' ?
                                    <ReactPlayer
                                        ref={player}
                                        // onEnded={() => setIscompleted(true)}
                                        // onProgress={(progress) => {
                                        //     setTimer(progress.playedSeconds);
                                        // }}

                                        className="react-player"
                                        // onPause={() => {
                                        //     convert_to_min(timer);
                                        // }}
                                        // playing={isPlaying}
                                        // controls
                                        width="100%"
                                        height="100%"
                                        url={readingContent}
                                    // style={{ pointerEvents: "none" }}
                                    />
                                    : contentType === "reading" ?
                                        <div className='readingContent'>
                                            <img className="readingContentImage" alt='' src={readingImage} />
                                            <span></span>
                                            <div
                                                className="openButton"
                                                onClick={() =>
                                                    window.open(readingContent, "_blank")
                                                }
                                            >
                                                <span>Open</span>
                                                <img src={opennew} alt="opennew" height={16} />
                                            </div>
                                        </div>
                                        :
                                        <div>
                                            course is locked
                                        </div>
                            }
                        </div>
                    </div>
                    <div className="studentLearnLeft">
                        <div className='studentLearnLeftNavbar'>
                            Course Content
                        </div>
                        <Accordion
                            //defaultActiveKey={eventKey}
                            activeKey={eventKey}
                            onSelect={(key) => setEventKey(key)}
                        >
                            {
                                isComplete?.length > 0 && enrolledCourseInfo?.topics?.map((item, index) => (
                                    <Accordion.Item
                                        eventKey={index + ""}
                                        key={index}>
                                        <Accordion.Header
                                            className={`  ${item?.isLocked ? "accordionButton" : "accordianHeader"}`}>
                                            {item?.topicName}
                                        </Accordion.Header>
                                        <Accordion.Body>
                                            <ul>
                                                {
                                                    item?.topicData?.length > 0 && item?.topicData?.map((ele, idx) => (
                                                        <li onClick={() => handleClickContent(ele, index, idx)} style={{
                                                            cursor: "pointer",
                                                            pointerEvents: item?.isLocked && "none",
                                                            color: item?.isLocked ? "#797A80" : isComplete[index][idx] ? "#654E8A" : "#424242",
                                                            fontSize: item?.isLocked && "13px",
                                                            fontWeight: item?.isLocked && "400",
                                                        }} key={idx}>
                                                            <div className='liDivAccordian'>
                                                                <img src={
                                                                    ele?.contentType === "Reading" ?
                                                                        isComplete[index][idx] ?
                                                                            readingIcon :
                                                                            ele?.isLocked ? readingIconLocked :
                                                                                readingIconNormal
                                                                        :
                                                                        isComplete[index][idx] ?
                                                                            videoIcon :
                                                                            ele?.isLocked ? videoIconLocked :
                                                                                videoIconNormal
                                                                } alt='' />
                                                                <span>{ele?.subtopic}</span>
                                                                {ele?.link1 && ele?.link2 && ele?.contentType === 'Video' && <a target='_blank' className='learnmore' href={ele?.link2} > Learn more</a>}
                                                            </div>
                                                            {!item?.isLocked && isComplete[index][idx] && <img src={completeTick} alt="" />
                                                            }
                                                        </li>
                                                    ))
                                                }
                                            </ul>
                                        </Accordion.Body>
                                    </Accordion.Item>
                                ))
                            }
                        </Accordion>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default UserLearnPage