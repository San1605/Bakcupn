import axios from "axios"
import { BASE_URL } from "../../../Utils/config";

async function authenticateUser(email, password) {
    const data = {
        username: email,
        password: password
    }
    let config = {
        method: "post",
        url: `${BASE_URL}/api/student/login`,
        headers: {
            "Content-Type": "application/json",
        },
        data: JSON.stringify(data)

    };
    try {
        const response = await axios(config);
        return response.data;
    } catch (error) {
        throw error.response.data;
    }
}

async function updatePasswordUser(current, updated) {
    const authToken = localStorage.getItem("token");
    const data = {
        current: current,
        password: updated
    };
    const config = {
        method: "patch",
        url: `${BASE_URL}/api/student/profile`,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        data: JSON.stringify(data),
    };

    try {
        const response = await axios(config);
        if (response.status >= 200 && response.status < 300) {
            return response.data;
        }
    } catch (error) {
        throw error.response.data;
    }
}

async function forgotPasswordUser(username) {
    const authToken = localStorage.getItem("token");
    const data = {
        username: username
    };
    const config = {
        method: "post",
        url: `${BASE_URL}/api/student/sendOTP`,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        data: JSON.stringify(data),
    };

    try {
        const response = await axios(config);
        if (response.status >= 200 && response.status < 300) {
            return response.data;
        }
    } catch (error) {
        throw error.response.data;
    }
}

async function otpUser(username, otp) {
    const authToken = localStorage.getItem("token");
    const data = {
        username: username,
        otp: otp
    };
    const config = {
        method: "post",
        url: `${BASE_URL}/api/student/validateOTP`,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        data: JSON.stringify(data),
    };

    try {
        const response = await axios(config);
        if (response.status >= 200 && response.status < 300) {
            return response.data;
        }
    } catch (error) {
        throw error.response.data;
    }
}

async function handleNewPassword(password) {
    const authToken = localStorage.getItem("token");
    const data = {
        fromOTP: 1,
        password: password
    };
    const config = {
        method: "patch",
        url: `${BASE_URL}/api/student/profile`,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        data: JSON.stringify(data),
    };

    try {
        const response = await axios(config);
        if (response.status >= 200 && response.status < 300) {
            return response.data;
        }
    } catch (error) {
        throw error.response.data;
    }
}


async function getMyCurrentCourse(courseId) {
    const authToken = localStorage.getItem("token");
    const config = {
        method: "get",
        url: `${BASE_URL}/api/student/getACourseDetailEnrolled?courseId=${courseId}`,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    }
    try {
        const response = await axios(config);
        if (response.status >= 200 && response.status < 300) {
            return { ...response.data?.data[0] }
        }
    } catch (error) {
        console.error(error);
        throw error.response.data;
    }
}

async function markAsComplete(courseId, subtopicId) {
    const authToken = localStorage.getItem("token");
    const data = {
        courseId: courseId,
        subTopicId: subtopicId
    }
    const config = {
        method: "post",
        url: `${BASE_URL}/api/student/courseCompleted`,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        data: JSON.stringify(data)
    }
    try {
        const response = await axios(config);
        if (response.status >= 200 && response.status < 300) {
            return response.data;
        }
    } catch (error) {
        console.error(error);
        throw error.response.data;
    }
}



async function getCourseListUser() {
    const authToken = localStorage.getItem("token");
    const config = {
        method: "get",
        url: `${BASE_URL}/api/student/getCourseList`,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    }
    try {
        const response = await axios(config);
        if (response.status >= 200 && response.status < 300) {
            return response.data
        }
    } catch (error) {
        console.error(error);
        throw error.response.data;
    }
}




export {
    authenticateUser,
    forgotPasswordUser,
    updatePasswordUser,
    handleNewPassword,
    otpUser,
    markAsComplete,
    getMyCurrentCourse,
    getCourseListUser
}