export const userInitialState = {
    enrolledCourseInfo: {},
    enrolledCourseList:[]
}

