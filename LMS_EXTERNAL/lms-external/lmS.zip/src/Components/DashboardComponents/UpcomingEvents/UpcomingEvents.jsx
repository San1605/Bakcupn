import React from 'react'
import "./UpcomingEvents.css"
import { upcomingEvents } from '../../../Assets/globalIcons'
const UpcomingEvents = () => {
    return (
        <div className="upcomingEvents">
            <div className='upcomingEventsHeading'>Upcoming Events</div>
            <div className='upcomingEventsDiv'>

                <div className='upComingEventImage'
                    style={{
                        backgroundImage: `url(${upcomingEvents})`,
                        backgroundSize: "cover",
                    }}
                >
                </div>

                <div className='UpcomingEventUpper'>
                    <div>Node js Sesion week 2</div>
                    {/* <div>Online</div> */}
                </div>

                <div className='UpcomingEventLower'>
                    <div>
                        <span>Date: 15jan 2023</span>
                        <span>Time: 10:00 AM</span>
                    </div>
                    <div>
                        <button>Join now</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UpcomingEvents
