import Chart from 'react-apexcharts'
import React from 'react'
import "./MostEnrolledCourses.css"
const MostEnrolledCourses = () => {
    const data = {
        options: {},
        series: [44, 55, 41, 17, 15],
        labels: ['A', 'B', 'C', 'D', 'E']
    }


    return (
        <div className="mostEnrolled">
            <div className='mostEnrolledHeading'>Most Enrolled Course</div>
            <div className='mostEnrolledDiv'>
                <div className="donut">
                    <Chart options={data.options} series={data.series} type="donut" width="250" />
                </div>
            </div>
        </div>
    )
}

export default MostEnrolledCourses