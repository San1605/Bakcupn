import React from 'react'

import { useNavigate } from 'react-router-dom';
import SearchBox from '../../SearchBox/SearchBox';
import { filter } from '../../../Assets/globalIcons';
const StudentsDetails = () => {
    const navigate = useNavigate();
    const dataArray = [
        {
            emailId: "email1@example.com",
            ContactNo: "1234567890",
            BtechStream: "Stream 1",
            CurrentSem: 1,
            Domain: "Domain 1"
        },
        {
            emailId: "email2@example.com",
            ContactNo: "2345678901",
            BtechStream: "Stream 2",
            CurrentSem: 2,
            Domain: "Domain 2"
        },
        {
            emailId: "email3@example.com",
            ContactNo: "3456789012",
            BtechStream: "Stream 3",
            CurrentSem: 3,
            Domain: "Domain 3"
        },
        {
            emailId: "email4@example.com",
            ContactNo: "4567890123",
            BtechStream: "Stream 4",
            CurrentSem: 4,
            Domain: "Domain 4"
        },
        {
            emailId: "email5@example.com",
            ContactNo: "5678901234",
            BtechStream: "Stream 5",
            CurrentSem: 5,
            Domain: "Domain 5"
        },
        {
            emailId: "email6@example.com",
            ContactNo: "6789012345",
            BtechStream: "Stream 6",
            CurrentSem: 6,
            Domain: "Domain 6"
        },
        {
            emailId: "email7@example.com",
            ContactNo: "7890123456",
            BtechStream: "Stream 7",
            CurrentSem: 7,
            Domain: "Domain 7"
        },
        {
            emailId: "email8@example.com",
            ContactNo: "8901234567",
            BtechStream: "Stream 8",
            CurrentSem: 8,
            Domain: "Domain 8"
        },
        {
            emailId: "email9@example.com",
            ContactNo: "9012345678",
            BtechStream: "Stream 9",
            CurrentSem: 9,
            Domain: "Domain 9"
        },
        {
            emailId: "email10@example.com",
            ContactNo: "0123456789",
            BtechStream: "Stream 10",
            CurrentSem: 10,
            Domain: "Domain 10"
        }
    ];


    return (
        <div className='collegeInformation'>
            <div className="collegeInformationHeading">
                <span>Student Details</span>
                <div className='lpListHeaderRight'>
                    <SearchBox
                        placeholder={"Search By Name"}
                    // searchQuery={searchQueryCollege}
                    // setSearchQuery={setSearchQueryCollege}
                    />

                    <img
                        style={{ cursor: "pointer", position: "relative" }}
                        src={filter}
                        alt=''
                    // onClick={() => setShowFilter(!showFilter)}
                    />
                </div>
            </div>
            <div className="collegeInformationDiv">
                <table>
                    <thead>
                        <tr className='headingRow'>
                            <th>Student Name</th>
                            <th>Email ID</th>
                            <th>Contact No.</th>
                            <th>Btech Stream</th>
                            <th>Current Sem</th>
                            <th>Domain</th>
                        </tr>
                    </thead>

                    <tbody className='tbodyAdminTable'>
                        {
                            dataArray?.map((item, index) => (
                                <tr style={{
                                    cursor: "pointer"
                                }}
                                    onClick={() => navigate(`/student/${item?.id}`)}
                                    className='tableRowadmin' key={index}>
                                    <td>Student</td>
                                    <td >{item?.emailId}</td>
                                    <td>{item?.ContactNo}</td>
                                    <td>{item?.BtechStream}</td>
                                    <td>{item?.CurrentSem}</td>
                                    <td>{item?.Domain}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default StudentsDetails
