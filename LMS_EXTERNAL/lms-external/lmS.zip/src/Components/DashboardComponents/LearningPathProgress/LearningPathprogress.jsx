import React from 'react'
import "./LearningPathprogress.css"
import LearningPatgProgressCard from './LearningPathProgressCard/LearningPatgProgressCard'
const LearningPathprogress = () => {
    return (
        <div className="LearningPathProgress">
            <div className='LearningPathProgressHeading'>Learning Path Progress</div>
            <div className='LearningPathProgressDiv'>
                {
                    [1,2]?.map((item) => (<LearningPatgProgressCard
                        CourseName="Node_001"
                        LpName="Node"
                        startDate="12/12/12"
                        endDate="12/12/12"
                        completedModules="21"
                        currentWeek="12"
                        runningState="false"
                    />))}
            </div>
        </div>
    )
}

export default LearningPathprogress
