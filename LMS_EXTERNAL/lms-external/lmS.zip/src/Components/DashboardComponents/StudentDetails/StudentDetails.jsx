import React from 'react'
import "./StudentDetails.css"
const StudentDetails = () => {
    return (
        <div>

        </div>
    )
}

export default StudentDetails