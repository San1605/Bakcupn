import Chart from "react-apexcharts";
import React from 'react'
import "./TopColleges.css"

const TopColleges = ({ role }) => {

    const state = {
        series: [{
            data: [400, 430, 448, 470, 540, 580, 690]
        }],
        options: {
            chart: {
                type: 'bar',
                height: "100%"
            },
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true,
                }
            },
            dataLabels: {
                enabled: false
            },
            xaxis: {
                categories: ['South Korea', 'Canada', 'United Kingdom', 'Netherlands', 'Italy', 'France', 'Japan'],
            }
        },

    };

    return (
        <div className='ProgressReport' style={{
            height: role === "hrBuddy" && "40%",
            width: role === "hrBuddy" && "100%"
        }}>
            <div className="progressReportHeading">
                Progress Report
            </div>
            <div className="progressReportDiv">
                <div className="reportParamsList">

                </div>
                <Chart
                    options={state.options}
                    series={state.series}
                    type="bar"
                    width="100%"
                    height="100%"
                />

            </div>
        </div>
    )
}

export default TopColleges
