import React from 'react'
import "./CollegeInformation.css"
import { useNavigate } from 'react-router-dom';
import SearchBox from "../../SearchBox/SearchBox"
import { filter } from '../../../Assets/globalIcons';
const CollegeInformation = () => {
    const navigate = useNavigate();
    const filteredLp = [
        {
            collegeName: "College 1",
            address: "Address 1",
            totalStudent: 100,
            totalDomain: "Domain 1"
        },
        {
            collegeName: "College 2",
            address: "Address 2",
            totalStudent: 120,
            totalDomain: "Domain 2"
        },
        {
            collegeName: "College 3",
            address: "Address 3",
            totalStudent: 90,
            totalDomain: "Domain 3"
        },
        {
            collegeName: "College 4",
            address: "Address 4",
            totalStudent: 110,
            totalDomain: "Domain 4"
        },
        {
            collegeName: "College 5",
            address: "Address 5",
            totalStudent: 80,
            totalDomain: "Domain 5"
        },
        {
            collegeName: "College 6",
            address: "Address 6",
            totalStudent: 130,
            totalDomain: "Domain 6"
        },
        {
            collegeName: "College 7",
            address: "Address 7",
            totalStudent: 95,
            totalDomain: "Domain 7"
        },
        {
            collegeName: "College 8",
            address: "Address 8",
            totalStudent: 105,
            totalDomain: "Domain 8"
        },
        {
            collegeName: "College 9",
            address: "Address 9",
            totalStudent: 115,
            totalDomain: "Domain 9"
        },
        {
            collegeName: "College 10",
            address: "Address 10",
            totalStudent: 85,
            totalDomain: "Domain 10"
        }
    ];

    return (
        <div className='collegeInformation'>
            <div className="collegeInformationHeading">
                <span>College Information</span>
                <div className='lpListHeaderRight'>
                    <SearchBox
                        placeholder={"Search By Name"}
                    // searchQuery={searchQueryCollege}
                    // setSearchQuery={setSearchQueryCollege}
                    />

                    <img
                        style={{ cursor: "pointer", position: "relative" }}
                        src={filter}
                        alt=''
                    // onClick={() => setShowFilter(!showFilter)}
                    />
                </div>
            </div>
            <div className="collegeInformationDiv">
                <table>
                    <thead>
                        <tr className='headingRow'>
                            <th>College Name</th>
                            <th>Address</th>
                            <th>Total Students</th>
                            <th>Total Domain</th>
                        </tr>
                    </thead>

                    <tbody className='tbodyAdminTable'>
                        {
                            filteredLp?.map((item, index) => (
                                <tr style={{
                                    cursor: "pointer"
                                }}
                                    onClick={() => navigate(`/college/${item?.id}`)}
                                    className='tableRowadmin' key={index}>
                                    <td >{item?.collegeName}</td>
                                    <td>{item?.address}</td>
                                    <td>{item?.totalStudent}</td>
                                    <td>{item?.totalDomain}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default CollegeInformation
