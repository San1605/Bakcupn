import React from 'react'
import "./SelectComponent.css"
const SelectComponent = () => {
  return (
      <select className='select'>
        <option>App Development</option>
      </select>
  )
}

export default SelectComponent
