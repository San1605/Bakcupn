// import React, { useEffect, useState } from "react";
// import { Calendar as BigCalendar, momentLocalizer } from "react-big-calendar";
// import moment from "moment";
// import "moment/locale/en-gb";
// import "react-big-calendar/lib/css/react-big-calendar.css";
// import "./Events.css";
// // import { getCalenderAppointments } from "../../../../services/commonApi";
// import { useParams } from "react-router-dom";

// const CalendarSection = () => {
//   const [currentDate, setCurrentDate] = useState(new Date());
//   const [eventsArr, setEventArr] = useState([]);
//   const localizer = momentLocalizer(moment);

//   const CustomTimeGutterHeader = () => {
//     return (
//       <div
//         className="custom-gutter-header"
//         style={{
//           display: "flex",
//           justifyContent: "center",
//           alignItems: "center",
//         }}
//       >
//         IST
//       </div>
//     );
//   };

//   const customDateHeaderFormat = (date, culture, localizer) => {
//     return `${localizer.format(date, "DD-MMM", culture)}`;
//   };

//   const isSunday = (date) => {
//     return date.getDay() === 0;
//   };

//   const dayPropGetter = (date) => {
//     const isSundayHoliday = isSunday(date);
//     if (isSundayHoliday) {
//       return {
//         className: "sunday-holiday",
//         style: {
//           backgroundColor: "#FFEDED !important",
//         },
//       };
//     }

//     return {};
//   };


//   // const startDate = moment(currentDate).startOf("week").format("YYYY-MM-DD");
//   // const endDate = moment(currentDate).endOf("week").format("YYYY-MM-DD");

//   // function convertDateStringToCustomDate(inputDate, inputTime) {
//   //   if (inputDate?.split("T").length > 0 && inputTime?.split("T").length > 0) {
//   //     const parts = inputDate?.split("T");
//   //     const datePart = parts[0]?.split("-");
//   //     const TimeString = inputTime?.split("T");
//   //     const timePart = TimeString[1]?.split(".")[0]?.split(":");

//   //     const year = parseInt(datePart[0]);
//   //     const month = parseInt(datePart[1]) - 1;
//   //     const day = parseInt(datePart[2]);

//   //     const hours = parseInt(timePart[0]);
//   //     const minutes = parseInt(timePart[1]);

//   //     return new Date(year, month, day, hours, minutes);
//   //   }
//   // }


//   // const { id } = useParams();
//   // const getCalendatEvents = async () => {
//   //   try {
//   //     const res = await getCalenderAppointments(id, startDate, endDate);
//   //     setEventArr(res?.data?.data);
//   //     console.log(res?.data?.data, "calender");
//   //   } catch (err) {
//   //     console.log(err);
//   //   }
//   // };

//   // useEffect(() => {
//   //   getCalendatEvents();
//   // }, []);

//   // const arrayOfEvents = [];

//   // eventsArr.map((event) => {
//   //   arrayOfEvents.push({
//   //     id: event.appointmentId,
//   //     title: event.problem,
//   //     start:
//   //       convertDateStringToCustomDate(
//   //         event.selectedAppointmentDate,
//   //         event.selectedAppointmentStartTime
//   //       ) || "1900-01-01T11:00:00.000Z",
//   //     end:
//   //       convertDateStringToCustomDate(
//   //         event.selectedAppointmentDate,
//   //         event.selectedAppointmentEndTime
//   //       ) || "1900-01-01T11:00:00.000Z",
//   //   });
//   // });


//   // const CustomEvent = ({ event }) => {
//   //   return (
//   //     <p
//   //       style={{
//   //         display: "flex",
//   //         alignItems: "center",
//   //         justifyContent: "center",
//   //         color: "black",
//   //         textAlign: "center",
//   //         fontSize: "10px",
//   //         height: "100%",
//   //         width: "100%",
//   //         overflow: "hidden",
//   //         whiteSpace: "nowrap",
//   //         textOverflow: "ellipsis",
//   //         // borderLeft:
//   //         //   event.title === "Appointment"
//   //         //     ? "3px solid #B979FC"
//   //         //     : "3px solid #FAAE00",
//   //       }}
//   //     >
//   //       Appointment
//   //     </p>
//   //   );
//   // };

//   return (
//     <div className="persona-list-right1 h-100">
//       <div className="d-flex justify-content-between align-items-center h-auto mt-1">
//         <span className="pre-text mx-2 ">Calendar</span>
//       </div>

//       <BigCalendar
//         localizer={localizer}
//         formats={{ dayFormat: customDateHeaderFormat }}
//         startAccessor="start"
//         // events={arrayOfEvents}
//         endAccessor="end"
//         culture={"en-gb"}
//         popup={true}
//         views={["week"]}
//         date={currentDate}
//         // defaultView="week"
//         min={moment().startOf("day").add(9, "hours").toDate()}
//         max={moment().startOf("day").add(19, "hours").toDate()}
//         now={new Date()}
//         dayPropGetter={dayPropGetter}
//         toolbar={null}
//         // components={{
//         //   event: CustomEvent,
//         //   timeGutterHeader: CustomTimeGutterHeader,
//         // }}
//       />
//     </div>
//   );
// };
// export default CalendarSection;





import React, { useEffect, useState } from "react";
import { Calendar as BigCalendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "moment/locale/en-gb";
import "react-big-calendar/lib/css/react-big-calendar.css";
import "./Events.css";


const Events = () => {

  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);

  const eventsArray = [
    {
      id: 1,
      title: "Meeting with Client 1",
      start: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 10, 0),
      end: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 11, 0),
      description: "Discuss project requirements with the client.",
    },
    {
      id: 2,
      title: "Lunch Break 2",
      start: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12, 0),
      end: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 13, 0),
      description: "Take a break and have lunch.",
    },
    {
      id: 3,
      title: "Workshop 3",
      start: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 14, 0),
      end: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 15, 0),
      description: "Attend a workshop on the latest technologies.",
    },
    {
      id: 4,
      title: "Coding Session 4",
      start: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 16, 0),
      end: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 17, 0),
      description: "Dedicated time for coding and development.",
    },
    {
      id: 5,
      title: "Project Review 5",
      start: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 18, 0),
      end: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 19, 0),
      description: "Review the progress of the ongoing project.",
    },
    // ... Add more events with unique titles, descriptions, and times
    {
      id: 16,
      title: "Team Building Activity 16",
      start: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 10, 0),
      end: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 11, 0),
      description: "Engage in a team-building activity.",
    },
    {
      id: 17,
      title: "Product Demo 17",
      start: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 12, 0),
      end: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 13, 0),
      description: "Demo of the latest product features.",
    },
    {
      id: 18,
      title: "Client Presentation 18",
      start: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 14, 0),
      end: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 15, 0),
      description: "Prepare and present project updates to the client.",
    },
    {
      id: 19,
      title: "Coding Challenge 19",
      start: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 16, 0),
      end: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 17, 0),
      description: "Complete coding challenge for job application.",
    },
    {
      id: 20,
      title: "Team Meeting 20",
      start: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 18, 0),
      end: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 19, 0),
      description: "Discuss project progress with the team.",
    },
  ];




  const localizer = momentLocalizer(moment);
  // const [currentDate, setCurrentDate] = React.useState(new Date());
  const [eventsArr, setEventArr] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const CustomTimeGutterHeader = () => {
    return (
      <div
        className="custom-gutter-header"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        IST
      </div>
    );
  };

  const customDateHeaderFormat = (date, culture, localizer) => `
${localizer.format(date, "dddd", culture)}
  ${localizer.format(date, "DD-MM-YYYY", culture)}
`;

  const isSunday = (date) => {
    return date.getDay() === 0;
  };

  const dayPropGetter = (date) => {
    const isSundayHoliday = isSunday(date);
    if (isSundayHoliday) {
      return {
        className: "sunday-holiday",
        style: {
          backgroundColor: "#FFEDED",
        },
      };
    }

    return {};
  };

  // const startDate = moment(currentDate).startOf("week").format("YYYY-MM-DD");
  // const endDate = moment(currentDate).endOf("week").format("YYYY-MM-DD");

  function convertDateStringToCustomDate(inputDate, inputTime) {
    if (inputDate?.split("T").length > 0 && inputTime?.split("T").length > 0) {
      const parts = inputDate?.split("T");
      const datePart = parts[0]?.split("-");
      const TimeString = inputTime?.split("T");
      const timePart = TimeString[1]?.split(".")[0]?.split(":");

      const year = parseInt(datePart[0]);
      const month = parseInt(datePart[1]) - 1;
      const day = parseInt(datePart[2]);

      const hours = parseInt(timePart[0]);
      const minutes = parseInt(timePart[1]);

      return new Date(year, month, day, hours, minutes);
    }
  }

  // const getCalendatEvents = async () => {
  //   let userId = localStorage.getItem("userId")
  //   try {
  //     const res = await getCalenderAppointments(userId, startDate, endDate);
  //     setEventArr(res?.data?.data);
  //     // console.log(res?.data?.data)
  //   } catch (err) {
  //     console.log(err);
  //   }
  // };
  // useEffect(() => {
  //   getCalendatEvents();
  // }, []);

  const arrayOfEvents = [];

  eventsArr?.map((event, index) => {
    arrayOfEvents.push({
      id: event.appointmentId,
      title: event.problem,
      start:
        convertDateStringToCustomDate(
          event?.selectedAppointmentDate,
          event?.selectedAppointmentStartTime
        ) || "1900-01-01T11:00:00.000Z",
      end:
        convertDateStringToCustomDate(
          event?.selectedAppointmentDate,
          event?.selectedAppointmentEndTime
        ) || "1900-01-01T11:00:00.000Z",
    });
  });

  const CustomEvent = ({ event }) => {
    return (
      <p
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "black",
          textAlign: "center",
          fontSize: "10px",
          height: "100%",
          width: "100%",
          borderLeft:
            event.title === "Appointment"
              ? "3px solid #B979FC"
              : "3px solid #FAAE00",
        }}
      >
        {/* {event.title} */}
        Appointment
      </p>
    );
  };

  // const CustomToolbar = ({ date, onNavigate }) => {
  //   const goToBack = () => {
  //     const newDate = new Date(currentDate);
  //     newDate.setDate(newDate.getDate() - 7);
  //     setCurrentDate(newDate);
  //   };

  //   const goToNext = () => {
  //     const newDate = new Date(currentDate);
  //     newDate.setDate(newDate.getDate() + 7);
  //     setCurrentDate(newDate);
  //   };

  //   const goToCurrent = () => {
  //     setCurrentDate(new Date());
  //   };

  //   const startDate = moment(currentDate).startOf("week").format("DD-MM-YYYY");
  //   const endDate = moment(currentDate).endOf("week").format("DD-MM-YYYY");

  //   return (
  //     <div
  //       className={"toolbar-container"}
  //       style={{
  //         textAlign: "right",
  //         marginBottom: "1rem",
  //         paddingBottom: "1rem",
  //         borderBottom: "2px solid #F1E3FF",
  //       }}
  //     >
  //       <div
  //         className={"back-next-buttons"}
  //         style={{
  //           border: "none",
  //         }}
  //       >
  //         <button
  //           className={"btn-back"}
  //           onClick={goToBack}
  //           style={{
  //             border: "none",
  //             marginRight: "0.6rem",
  //             fontSize: "1.2rem",
  //             backgroundColor: "transparent",
  //           }}
  //         >
  //           &#8249;
  //         </button>
  //         <button
  //           className={"btn-current"}
  //           onClick={goToCurrent}
  //           style={{
  //             border: "none",
  //             fontSize: "0.8rem",
  //             backgroundColor: "transparent",
  //           }}
  //         >
  //           <span
  //             style={{
  //               backgroundColor: "#F1E3FF",
  //               padding: "0.5rem",
  //               marginRight: "0.3rem",
  //             }}
  //           >{`${startDate}`}</span>
  //           -
  //           <span
  //             style={{
  //               backgroundColor: "#F1E3FF",
  //               padding: "0.5rem",
  //               marginLeft: "0.3rem",
  //             }}
  //           >{` ${endDate}`}</span>
  //         </button>

  //         <button
  //           className={"btn-next"}
  //           onClick={goToNext}
  //           style={{
  //             border: "none",
  //             marginLeft: "0.6rem",
  //             fontSize: "1.2rem",
  //             backgroundColor: "transparent",
  //           }}
  //         >
  //           &#8250;
  //         </button>
  //       </div>
  //     </div>
  //   );
  // };

  const handleSelectEvent = (event) => {
    console.log("Selected event:", event);
  };

  const handleDoubleClickEvent = (event) => {
    console.log("Double-clicked event:", event);
  };
  const handleSelectSlot = (slotInfo) => {
    console.log("Selected slot:", slotInfo);
    setShowModal(true);
  };

  return (
    <div className="Events">
      <div className="home-top">
        {/* <h3 className="heading-overview mb-0">My Calendar</h3>
        <h2 className="heading-homepage mb-0">My Calendar</h2> */}
      </div>
      <BigCalendar
        localizer={localizer}
        formats={{ dayFormat: customDateHeaderFormat }}
        startAccessor="start"
        events={eventsArray}
        endAccessor="end"
        culture={"en-gb"}
        popup={true}
        // views={['week', 'day', 'agenda']}
        // date={currentDate}
        defaultView="week"
        // step={60} // Set the step to 60 (for 60 minutes)
        min={moment().startOf("day").add(10, "hours").toDate()} // Set the minimum time to 9 AM
        max={moment().startOf("day").add(20, "hours").toDate()} // Set the maximum time to 7 PM (adjust as needed)
        now={new Date()}
        dayPropGetter={dayPropGetter}
        // eventPropGetter={customEventStyleGetter}
        components={{
          // event: CustomEvent,
          timeGutterHeader: CustomTimeGutterHeader,
          // toolbar: CustomToolbar,
        }}
        onSelectEvent={handleSelectEvent}
        onDoubleClickEvent={handleDoubleClickEvent}
        onSelectSlot={handleSelectSlot}
        selectable={true}
      />
      {/* <DoctorCalenderModal
        show={showModal}
        setShow={setShowModal}
        //  onClose={() => setShowModal(false)}
      /> */}
    </div>
  );
};

export default Events;
