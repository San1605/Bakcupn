import COE_1 from "./COE_IMG/COE_1.webp"
import COE_2 from "./COE_IMG/COE_2.webp"
import COE_3 from "./COE_IMG/COE_3.webp"
import COE_4 from "./COE_IMG/COE_4.webp"
import COE_5 from "./COE_IMG/COE_5.webp"
import COE_6 from "./COE_IMG/COE_6.webp"
import COE_7 from "./COE_IMG/COE_7.webp"
import COE_8 from "./COE_IMG/COE_8.webp"
import COE_9 from "./COE_IMG/COE_9.webp"
import COE_10 from "./COE_IMG/COE_10.webp"
import COE_11 from "./COE_IMG/COE_11.webp"
import COE_12 from "./COE_IMG/COE_12.webp"
import COE_13 from "./COE_IMG/COE_13.webp"
import COE_14 from "./COE_IMG/COE_14.webp"
import COE_15 from "./COE_IMG/COE_15.webp"

export {
    COE_1,
    COE_2,
    COE_3,
    COE_4,
    COE_5,
    COE_6,
    COE_7,
    COE_8,
    COE_9,
    COE_10,
    COE_11,
    COE_12,
    COE_13,
    COE_14,
    COE_15,
}
